window.__require = function e(t, n, r) {
  function s(o, u) {
    if (!n[o]) {
      if (!t[o]) {
        var b = o.split("/");
        b = b[b.length - 1];
        if (!t[b]) {
          var a = "function" == typeof __require && __require;
          if (!u && a) return a(b, !0);
          if (i) return i(b, !0);
          throw new Error("Cannot find module '" + o + "'");
        }
        o = b;
      }
      var f = n[o] = {
        exports: {}
      };
      t[o][0].call(f.exports, function(e) {
        var n = t[o][1][e];
        return s(n || e);
      }, f, f.exports, e, t, n, r);
    }
    return n[o].exports;
  }
  var i = "function" == typeof __require && __require;
  for (var o = 0; o < r.length; o++) s(r[o]);
  return s;
}({
  GameOneEvents: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "6182evXr0dMhq+fEaaNwrtU", "GameOneEvents");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.GameOneEvents = void 0;
    var GameOneEvents = function() {
      function GameOneEvents() {}
      GameOneEvents.OPEN_GAMEONE_MODULE = "OPEN_GAMEONE_MODULE";
      return GameOneEvents;
    }();
    exports.GameOneEvents = GameOneEvents;
    cc._RF.pop();
  }, {} ],
  GameOneGameEntry: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "5ac45YBYg9D6LaqED0WaQ4+", "GameOneGameEntry");
    "use strict";
    var __extends = this && this.__extends || function() {
      var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function(d, b) {
          d.__proto__ = b;
        } || function(d, b) {
          for (var p in b) b.hasOwnProperty(p) && (d[p] = b[p]);
        };
        return extendStatics(d, b);
      };
      return function(d, b) {
        extendStatics(d, b);
        function __() {
          this.constructor = d;
        }
        d.prototype = null === b ? Object.create(b) : (__.prototype = b.prototype, new __());
      };
    }();
    var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : null === desc ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if ("object" === typeof Reflect && "function" === typeof Reflect.decorate) r = Reflect.decorate(decorators, target, key, desc); else for (var i = decorators.length - 1; i >= 0; i--) (d = decorators[i]) && (r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r);
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.GameOneGameEntry = void 0;
    var Decorator_1 = require("../../../script/Framework/Decorator/Decorator");
    var GameEntry_1 = require("../../../script/Framework/Support/Entry/GameEntry");
    var GameOneModuleConfig_1 = require("./Config/GameOneModuleConfig");
    var GameOneEvents_1 = require("./Events/GameOneEvents");
    var GameOneGameEntry = function(_super) {
      __extends(GameOneGameEntry, _super);
      function GameOneGameEntry() {
        return null !== _super && _super.apply(this, arguments) || this;
      }
      GameOneGameEntry.prototype.initEntry = function() {
        _super.prototype.initEntry.call(this);
        this.addModules(GameOneModuleConfig_1.GameOneModuleConfig);
      };
      GameOneGameEntry.prototype.initViews = function() {
        manager.eventManager.dispatchEventWith(GameOneEvents_1.GameOneEvents.OPEN_GAMEONE_MODULE);
      };
      GameOneGameEntry.prototype.closeViews = function() {
        this.closeModule(GameOneModuleConfig_1.GameOneModuleConfig.GameOneModule);
      };
      GameOneGameEntry = __decorate([ Decorator_1.ClassName(), Decorator_1.RegisterGameEntry("gameOne") ], GameOneGameEntry);
      return GameOneGameEntry;
    }(GameEntry_1.GameEntry);
    exports.GameOneGameEntry = GameOneGameEntry;
    cc._RF.pop();
  }, {
    "../../../script/Framework/Decorator/Decorator": void 0,
    "../../../script/Framework/Support/Entry/GameEntry": void 0,
    "./Config/GameOneModuleConfig": "GameOneModuleConfig",
    "./Events/GameOneEvents": "GameOneEvents"
  } ],
  GameOneModuleConfig: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "81b71lQkBBCi6CQaUUInx3i", "GameOneModuleConfig");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.GameOneModuleConfig = void 0;
    var Layer_1 = require("../../../../script/Framework/Defineds/Enums/Layer");
    var GameOneEvents_1 = require("../Events/GameOneEvents");
    var GameOneModule_1 = require("../Modules/GameOneModule");
    exports.GameOneModuleConfig = {
      GameOneModule: {
        component: GameOneModule_1.default,
        event: GameOneEvents_1.GameOneEvents.OPEN_GAMEONE_MODULE,
        layer: Layer_1.Layer.GameLayer.Content,
        zIndex: 0,
        name: "GameOneModule",
        onShowedFuncName: null
      }
    };
    cc._RF.pop();
  }, {
    "../../../../script/Framework/Defineds/Enums/Layer": void 0,
    "../Events/GameOneEvents": "GameOneEvents",
    "../Modules/GameOneModule": "GameOneModule"
  } ],
  GameOneModule: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "91d07Gl+Z5D+qjqmeSxT/pn", "GameOneModule");
    "use strict";
    var __extends = this && this.__extends || function() {
      var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function(d, b) {
          d.__proto__ = b;
        } || function(d, b) {
          for (var p in b) b.hasOwnProperty(p) && (d[p] = b[p]);
        };
        return extendStatics(d, b);
      };
      return function(d, b) {
        extendStatics(d, b);
        function __() {
          this.constructor = d;
        }
        d.prototype = null === b ? Object.create(b) : (__.prototype = b.prototype, new __());
      };
    }();
    var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : null === desc ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if ("object" === typeof Reflect && "function" === typeof Reflect.decorate) r = Reflect.decorate(decorators, target, key, desc); else for (var i = decorators.length - 1; i >= 0; i--) (d = decorators[i]) && (r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r);
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var ModuleComponent_1 = require("../../../../script/Framework/Component/ModuleComponent");
    var ccclass = cc._decorator.ccclass;
    var GameOneModule = function(_super) {
      __extends(GameOneModule, _super);
      function GameOneModule() {
        return null !== _super && _super.apply(this, arguments) || this;
      }
      GameOneModule.getPrefabUrl = function() {
        return "prefabs/GameOneModule";
      };
      GameOneModule.prototype.show = function(option) {
        option.onShowed();
      };
      GameOneModule.prototype.hide = function(option) {
        option.onHided();
      };
      GameOneModule.prototype.onLoad = function() {
        var goBack = this.find("goBack");
        goBack.on(cc.Node.EventType.TOUCH_END, this._goBack, this);
      };
      GameOneModule.prototype._goBack = function() {
        manager.enteyManager.stopGameEntry("GameOneGameEntry");
      };
      GameOneModule = __decorate([ ccclass ], GameOneModule);
      return GameOneModule;
    }(ModuleComponent_1.ModuleComponent);
    exports.default = GameOneModule;
    cc._RF.pop();
  }, {
    "../../../../script/Framework/Component/ModuleComponent": void 0
  } ]
}, {}, [ "GameOneModuleConfig", "GameOneEvents", "GameOneGameEntry", "GameOneModule" ]);