window.__require = function e(t, n, r) {
  function s(o, u) {
    if (!n[o]) {
      if (!t[o]) {
        var b = o.split("/");
        b = b[b.length - 1];
        if (!t[b]) {
          var a = "function" == typeof __require && __require;
          if (!u && a) return a(b, !0);
          if (i) return i(b, !0);
          throw new Error("Cannot find module '" + o + "'");
        }
        o = b;
      }
      var f = n[o] = {
        exports: {}
      };
      t[o][0].call(f.exports, function(e) {
        var n = t[o][1][e];
        return s(n || e);
      }, f, f.exports, e, t, n, r);
    }
    return n[o].exports;
  }
  var i = "function" == typeof __require && __require;
  for (var o = 0; o < r.length; o++) s(r[o]);
  return s;
}({
  Application: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "2eba9tOINlPvYnpFexVo0qa", "Application");
    "use strict";
    var __extends = this && this.__extends || function() {
      var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function(d, b) {
          d.__proto__ = b;
        } || function(d, b) {
          for (var p in b) b.hasOwnProperty(p) && (d[p] = b[p]);
        };
        return extendStatics(d, b);
      };
      return function(d, b) {
        extendStatics(d, b);
        function __() {
          this.constructor = d;
        }
        d.prototype = null === b ? Object.create(b) : (__.prototype = b.prototype, new __());
      };
    }();
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.Application = void 0;
    var PopupControll_1 = require("./Common/Component/PopupControll");
    var ProcessLoading_1 = require("./Common/Component/ProcessLoading");
    var EUIManager_1 = require("./Framework/Defineds/Events/EUIManager");
    var Framework_1 = require("./Framework/Framework");
    var Application = function(_super) {
      __extends(Application, _super);
      function Application() {
        return null !== _super && _super.apply(this, arguments) || this;
      }
      Object.defineProperty(Application.prototype, "isBrower", {
        get: function() {
          return cc.sys.platform == cc.sys.WECHAT_GAME || cc.sys.isBrowser;
        },
        enumerable: false,
        configurable: true
      });
      Object.defineProperty(Application.prototype, "popupControll", {
        get: function() {
          return PopupControll_1.PopupControll.Instance;
        },
        enumerable: false,
        configurable: true
      });
      Object.defineProperty(Application.prototype, "processLoading", {
        get: function() {
          return ProcessLoading_1.ProcessLoading.Instance;
        },
        enumerable: false,
        configurable: true
      });
      Application.prototype.init = function() {
        this.popupControll.preloadPrefab();
        this.processLoading.preloadPrefab();
        this.eventManager.addEvent(this, EUIManager_1.EUIManager.SHOW_LOADING, this._showLoadingProgess);
        this.eventManager.addEvent(this, EUIManager_1.EUIManager.HIDE_LOADING, this._hideLodingProgess);
      };
      Application.prototype._hideLodingProgess = function() {
        this.processLoading.hide();
      };
      Application.prototype._showLoadingProgess = function(process) {
        this.processLoading.show(process.data.progress + "%");
      };
      return Application;
    }(Framework_1.Framework);
    exports.Application = Application;
    (function() {
      false;
      window["manager"] = new Application();
      manager.init();
    })();
    cc._RF.pop();
  }, {
    "./Common/Component/PopupControll": "PopupControll",
    "./Common/Component/ProcessLoading": "ProcessLoading",
    "./Framework/Defineds/Events/EUIManager": "EUIManager",
    "./Framework/Framework": "Framework"
  } ],
  AssetsManager: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "6181a/KcxdBXJ9DetFqBXKB", "AssetsManager");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.AssetsManager = void 0;
    var ResourceCacheStatus_1 = require("../../Defineds/Enums/ResourceCacheStatus");
    var IResource_1 = require("../../Defineds/Interfaces/IResource");
    var CacheManager_1 = require("./CacheManager");
    var RemoteLoader_1 = require("./RemoteLoader");
    var AssetsManager = function() {
      function AssetsManager() {
        this._remote = new RemoteLoader_1.RemoteLoader();
      }
      Object.defineProperty(AssetsManager, "Instance", {
        get: function() {
          return this._instance || (this._instance = new AssetsManager());
        },
        enumerable: false,
        configurable: true
      });
      Object.defineProperty(AssetsManager.prototype, "remote", {
        get: function() {
          return this._remote;
        },
        enumerable: false,
        configurable: true
      });
      AssetsManager.prototype.loadBundle = function(nameOrUrl, onCompolete) {
        cc.assetManager.loadBundle(nameOrUrl, onCompolete);
      };
      AssetsManager.prototype.removeBundle = function(bundle) {
        var result = this.getBundle(bundle);
        if (result) {
          CacheManager_1.CacheManager.Instance.removeBundle(bundle);
          result.releaseAll();
          cc.assetManager.removeBundle(result);
        }
      };
      AssetsManager.prototype.getBundle = function(bundle) {
        if (bundle) {
          if ("string" == typeof bundle) return cc.assetManager.getBundle(bundle);
          return bundle;
        }
        return null;
      };
      AssetsManager.prototype.releaseAsset = function(info) {
        if (info && info.bundle) {
          var cache = CacheManager_1.CacheManager.Instance.get(info.bundle, info.url, false);
          if (!cache) return;
          if (cache.isInvalid) {
            true;
            cc.warn("[AssetManager]", "\u8d44\u6e90\u5df2\u7ecf\u91ca\u653e url : " + info.url);
            return;
          }
          if (cache.isLoaded) {
            if (cache.info.retain) {
              true;
              cc.log("[AssetManager]", "\u5e38\u9a7b\u8d44\u6e90 url : " + cache.info.url);
              return;
            }
            true;
            cc.log("[AssetManager]", "\u91ca\u653e\u8d44\u6e90 : " + info.bundle + "." + info.url);
            if (CacheManager_1.CacheManager.Instance.removeWithInfo(info)) {
              var bundle = this.getBundle(info.bundle);
              if (bundle) if (Array.isArray(info.data)) {
                for (var i = 0; i < info.data.length; i++) {
                  var path = info.url + "/" + info.data[i].name;
                  bundle.release(path, info.type);
                }
                true;
                cc.log("[AssetManager]", "\u6210\u529f\u91ca\u653e\u8d44\u6e90\u76ee\u5f55 : " + info.bundle + "." + info.url);
              } else {
                bundle.release(info.url, info.type);
                true;
                cc.log("[AssetManager]", "\u6210\u529f\u91ca\u653e\u8d44\u6e90 : " + info.bundle + "." + info.url);
              } else cc.error("[AssetManager]", info.bundle + " no found");
            } else {
              true;
              if (Array.isArray(info.data)) for (var i = 0; i < info.data.length; i++) 0 != info.data[i].refCount && cc.warn("[AssetManager]", "\u8d44\u6e90bundle : " + info.bundle + " url : " + info.url + "/" + info.data[i].name + " \u88ab\u5176\u5b83\u754c\u9762\u5f15\u7528 refCount : " + info.data[i].refCount); else cc.warn("[AssetManager]", "\u8d44\u6e90bundle : " + info.bundle + " url : " + info.url + " \u88ab\u5176\u5b83\u754c\u9762\u5f15\u7528 refCount : " + info.data.refCount);
            }
          } else {
            cache.status = ResourceCacheStatus_1.ResourceCacheStatus.WAITTING_FOR_RELEASE;
            true;
            cc.warn("[AssetManager]", cache.info.url + " \u6b63\u5728\u52a0\u8f7d\uff0c\u7b49\u5f85\u52a0\u8f7d\u5b8c\u6210\u540e\u8fdb\u884c\u91ca\u653e");
          }
        }
      };
      AssetsManager.prototype.retainAsset = function(info) {
        if (info) {
          var cache = CacheManager_1.CacheManager.Instance.get(info.bundle, info.url);
          if (cache) {
            true;
            info.data != cache.data && cc.error("[AssetManager]", "\u9519\u8bef\u7684retainAsset :" + info.url);
            cache.info.retain || (cache.info.retain = info.retain);
            if (Array.isArray(cache.data)) for (var i = 0; i < cache.data.length; i++) cache.data[i] && cache.data[i].addRef(); else cache.data && cache.data.addRef();
          } else {
            true;
            cc.error("[AssetManager]", "retainAsset cache.data is null");
          }
        } else {
          true;
          cc.error("[AssetManager]", "retainAsset info is null");
        }
      };
      AssetsManager.prototype.load = function(bundle, path, type, onProgress, onComplete) {
        true;
        cc.log("[AssteManager]", "load bundle : " + bundle + " path : " + path);
        var cache = CacheManager_1.CacheManager.Instance.get(bundle, path);
        if (cache) {
          if (cache.isLoaded) {
            (true, cache.status == ResourceCacheStatus_1.ResourceCacheStatus.WAITTING_FOR_RELEASE) && cc.warn("[AssetManager]", "\u8d44\u6e90:" + path + " \u7b49\u5f85\u91ca\u653e\uff0c\u4f46\u8d44\u6e90\u5df2\u7ecf\u52a0\u8f7d\u5b8c\u6210\uff0c\u6b64\u65f6\u6709\u4eba\u53c8\u91cd\u65b0\u52a0\u8f7d\uff0c\u4e0d\u8fdb\u884c\u91ca\u653e\u5904\u7406");
            onComplete(cache);
          } else {
            (true, cache.status == ResourceCacheStatus_1.ResourceCacheStatus.WAITTING_FOR_RELEASE) && cc.warn("AssetManager", "\u8d44\u6e90:" + path + "\u7b49\u5f85\u91ca\u653e\uff0c\u4f46\u8d44\u6e90\u5904\u7406\u52a0\u8f7d\u8fc7\u7a0b\u4e2d\uff0c\u6b64\u65f6\u6709\u4eba\u53c8\u91cd\u65b0\u52a0\u8f7d\uff0c\u4e0d\u8fdb\u884c\u91ca\u653e\u5904\u7406");
            cache.finishCb.push(onComplete);
          }
          cache.status = ResourceCacheStatus_1.ResourceCacheStatus.NONE;
        } else {
          cache = new IResource_1.IResource.ResourceCacheData();
          cache.info.url = path;
          cache.info.type = type;
          cache.info.bundle = bundle;
          CacheManager_1.CacheManager.Instance.set(bundle, path, cache);
          var _bundle = this.getBundle(bundle);
          if (!_bundle) {
            var error = new Error("[AssetManager] " + bundle + " \u6ca1\u6709\u52a0\u8f7d\uff0c\u8bf7\u5148\u52a0\u8f7d");
            this._onLoadComplete(cache, onComplete, error, null);
            return;
          }
          var res = _bundle.get(path, type);
          res ? this._onLoadComplete(cache, onComplete, null, res) : onProgress ? _bundle.load(path, type, onProgress, this._onLoadComplete.bind(this, cache, onComplete)) : _bundle.load(path, type, this._onLoadComplete.bind(this, cache, onComplete));
        }
      };
      AssetsManager.prototype._onLoadComplete = function(cache, completeCallback, err, data) {
        cache.isLoaded = true;
        var tempCache = cache;
        if (err) {
          cc.error("[AssetManager]", "\u52a0\u8f7d\u8d44\u6e90\u5931\u8d25:" + cache.info.url + " \u539f\u56e0:" + (err.message ? err.message : "\u672a\u77e5"));
          cache.data = null;
          tempCache.data = null;
          CacheManager_1.CacheManager.Instance.remove(cache.info.bundle, cache.info.url);
          completeCallback(cache);
        } else {
          true;
          cc.log("[AssetManager]", "\u52a0\u8f7d\u8d44\u6e90\u6210\u529f:" + cache.info.url);
          cache.data = data;
          tempCache.data = data;
          completeCallback(cache);
        }
        cache.doFinish(tempCache);
        cache.doGet(tempCache.data);
        if (cache.status == ResourceCacheStatus_1.ResourceCacheStatus.WAITTING_FOR_RELEASE) {
          true;
          cc.warn("[AssetManager]", "\u8d44\u6e90:" + cache.info.url + "\u52a0\u8f7d\u5b8c\u6210\uff0c\u4f46\u7f13\u5b58\u72b6\u6001\u4e3a\u7b49\u5f85\u9500\u6bc1\uff0c\u9500\u6bc1\u8d44\u6e90");
          if (cache.data) {
            cache.status = ResourceCacheStatus_1.ResourceCacheStatus.NONE;
            var info = new IResource_1.IResource.ResourceInfo();
            info.url = cache.info.url;
            info.type = cache.info.type;
            info.data = cache.data;
            info.bundle = cache.info.bundle;
            this.releaseAsset(info);
          }
        }
      };
      AssetsManager.prototype.addPersistAsset = function(url, data, bundle) {
        var info = new IResource_1.IResource.ResourceInfo();
        info.url = url;
        info.data = data;
        info.bundle = bundle;
        info.retain = true;
        this.retainAsset(info);
      };
      AssetsManager._instance = null;
      return AssetsManager;
    }();
    exports.AssetsManager = AssetsManager;
    cc._RF.pop();
  }, {
    "../../Defineds/Enums/ResourceCacheStatus": "ResourceCacheStatus",
    "../../Defineds/Interfaces/IResource": "IResource",
    "./CacheManager": "CacheManager",
    "./RemoteLoader": "RemoteLoader"
  } ],
  BitEncrypt: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "9f7a53hB2VIw4Llz1olSeQy", "BitEncrypt");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.BitEncrypt = void 0;
    var BitEncrypt = function() {
      function BitEncrypt() {}
      Object.defineProperty(BitEncrypt, "encryptKey", {
        get: function() {
          return this._encryptKey;
        },
        set: function(value) {
          this._encryptKey = value;
        },
        enumerable: false,
        configurable: true
      });
      BitEncrypt.decode = function(content, key) {
        return this._code(content, key);
      };
      BitEncrypt.encode = function(content, key) {
        return this._code(content, key);
      };
      BitEncrypt._code = function(content, key) {
        var result = this._check(content, key);
        if (result.isOK) {
          var contentCharCode = [];
          for (var i = 0; i < content.length; i++) contentCharCode.push(content.charCodeAt(i));
          var index = 0;
          var ch = "";
          var regex = /[\w\d_-`~#!$%^&*(){}=+;:'"<,>,\/?|\\\u4e00-\u9fa5]/g;
          for (var i = 0; i < contentCharCode.length; i++) {
            var matchs = content[i].match(regex);
            if (matchs && matchs.length > 0) {
              contentCharCode[i] ^= result.key.charCodeAt(index);
              ch = String.fromCharCode(contentCharCode[i]);
              matchs = ch.match(regex);
              matchs && matchs.length || (contentCharCode[i] ^= result.key.charCodeAt(index));
              index++;
              index >= result.key.length && (index = 0);
            }
          }
          var newContent = "";
          for (var i = 0; i < contentCharCode.length; i++) newContent += String.fromCharCode(contentCharCode[i]);
          return newContent;
        }
        true;
        cc.error(this.logTag, "encode/decode error content : " + content + " key : " + key);
        return content;
      };
      BitEncrypt._check = function(content, key) {
        return content && content.length > 0 ? key && key.length > 0 ? {
          isOK: true,
          key: key
        } : this.encryptKey && this.encryptKey.length > 0 ? {
          isOK: true,
          key: this.encryptKey
        } : {
          isOK: false,
          key: key
        } : {
          isOK: false,
          key: key
        };
      };
      BitEncrypt.logTag = "[BitEncrypt]:";
      BitEncrypt._encryptKey = "EskKbMvzZBILhcTv";
      return BitEncrypt;
    }();
    exports.BitEncrypt = BitEncrypt;
    cc._RF.pop();
  }, {} ],
  BootModule: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "c076dTFYl1F4azYB/MiTo/U", "BootModule");
    "use strict";
    var __extends = this && this.__extends || function() {
      var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function(d, b) {
          d.__proto__ = b;
        } || function(d, b) {
          for (var p in b) b.hasOwnProperty(p) && (d[p] = b[p]);
        };
        return extendStatics(d, b);
      };
      return function(d, b) {
        extendStatics(d, b);
        function __() {
          this.constructor = d;
        }
        d.prototype = null === b ? Object.create(b) : (__.prototype = b.prototype, new __());
      };
    }();
    var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : null === desc ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if ("object" === typeof Reflect && "function" === typeof Reflect.decorate) r = Reflect.decorate(decorators, target, key, desc); else for (var i = decorators.length - 1; i >= 0; i--) (d = decorators[i]) && (r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r);
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var ModuleComponent_1 = require("../../Framework/Component/ModuleComponent");
    var MainEvents_1 = require("../Events/MainEvents");
    var ccclass = cc._decorator.ccclass;
    var BootModule = function(_super) {
      __extends(BootModule, _super);
      function BootModule() {
        var _this = null !== _super && _super.apply(this, arguments) || this;
        _this._info = null;
        return _this;
      }
      BootModule.getPrefabUrl = function() {
        return "prefabs/BootModule";
      };
      BootModule.prototype.show = function(option) {
        option.onShowed();
      };
      BootModule.prototype.hide = function(option) {
        option.onHided();
      };
      BootModule.prototype.onLoad = function() {
        this._info = this.getComByPath(cc.Label, "info");
        this._checkPlatform();
      };
      BootModule.prototype._checkPlatform = function() {
        var _this = this;
        this._info.string = "\u6b63\u5728\u68c0\u67e5\u5f53\u524d\u8fd0\u884c\u73af\u5883";
        this.scheduleOnce(function() {
          manager.isBrower ? _this._Web() : _this._native();
        }, .5);
      };
      BootModule.prototype._Web = function() {
        var _this = this;
        this.scheduleOnce(function() {
          _this._info.string = "\u6b63\u5728\u83b7\u53d6\u7cfb\u7edf\u516c\u544a";
          _this._joinLoginOrMain();
        }, .5);
      };
      BootModule.prototype._native = function() {
        var _this = this;
        this.scheduleOnce(function() {
          _this._info.string = "\u6b63\u5728\u521d\u59cb\u5316\u7248\u672c\u4fe1\u606f";
          _this._joinLoginOrMain();
        }, .5);
      };
      BootModule.prototype._joinLoginOrMain = function() {
        var _this = this;
        this.scheduleOnce(function() {
          _this._info.string = "\u6b63\u5728\u8fdb\u5165\u6e38\u620f\u754c\u9762";
          manager.eventManager.dispatchEventWith(MainEvents_1.MainEvents.OPEN_LOGIN_MODULE);
        }, 1);
      };
      BootModule.prototype.click = function() {};
      BootModule = __decorate([ ccclass ], BootModule);
      return BootModule;
    }(ModuleComponent_1.ModuleComponent);
    exports.default = BootModule;
    cc._RF.pop();
  }, {
    "../../Framework/Component/ModuleComponent": "ModuleComponent",
    "../Events/MainEvents": "MainEvents"
  } ],
  BundleManager: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "32fc3CoNNRCvar22J4LJEJZ", "BundleManager");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.BundleOption = exports.BundleManager = void 0;
    var AssetsManager_1 = require("../Assets/AssetsManager");
    var EntryManager_1 = require("./../Entry/EntryManager");
    var EBundle_1 = require("../../Defineds/Events/EBundle");
    var EventManager_1 = require("../Event/EventManager");
    var BundleManager = function() {
      function BundleManager() {
        this._isLoading = false;
        this._curBundleOtion = null;
        this.loadedBundle = [];
      }
      Object.defineProperty(BundleManager, "Instance", {
        get: function() {
          return this._instance || (this._instance = new BundleManager());
        },
        enumerable: false,
        configurable: true
      });
      BundleManager.prototype.removeLoadedBundle = function() {
        this.loadedBundle.forEach(function(value, index, origin) {
          AssetsManager_1.AssetsManager.Instance.removeBundle(value);
        });
        this.loadedBundle = [];
      };
      BundleManager.prototype.removeLoadedGamesBundle = function() {
        var i = this.loadedBundle.length;
        while (i--) {
          AssetsManager_1.AssetsManager.Instance.removeBundle(this.loadedBundle[i]);
          this.loadedBundle.splice(i, 1);
        }
      };
      BundleManager.prototype.entryBundle = function(opt) {
        if (this._isLoading) {
          EventManager_1.EventManager.dispatchEventWith(EBundle_1.EBundle.BUNDLE_LOADING, {
            name: this._curBundleOtion.name
          });
          return;
        }
        this._curBundleOtion = opt;
        this._isLoading = true;
        this._loadBundle();
      };
      BundleManager.prototype._loadBundle = function() {
        var _this = this;
        cc.log("[BundleManager]", "update Game : " + this._curBundleOtion.bundleName);
        AssetsManager_1.AssetsManager.Instance.loadBundle(this._curBundleOtion.bundleName, function(err, bundle) {
          _this._isLoading = false;
          if (err) {
            cc.error("[BundleManager]", "\u52a0\u8f7d bundle : " + _this._curBundleOtion.name + " \u5931\u8d25 !!!");
            EventManager_1.EventManager.dispatchEventWith(EBundle_1.EBundle.LOAD_BUNDLE_FAIL, {
              name: _this._curBundleOtion.name
            });
          } else {
            cc.log("[BundleManager]", "\u52a0\u8f7d bundle : " + _this._curBundleOtion.name + " \u6210\u529f !!!");
            -1 == _this.loadedBundle.indexOf(_this._curBundleOtion.bundleName) && _this.loadedBundle.push(_this._curBundleOtion.bundleName);
            _this.onGameReady();
          }
        });
      };
      BundleManager.prototype.onGameReady = function() {
        this._isLoading && (this._isLoading = false);
        null != this._curBundleOtion.EntryGame && "" != this._curBundleOtion.EntryGame && EntryManager_1.EntryManager.startGameEntry(this._curBundleOtion.EntryGame);
        this._curBundleOtion.onComplete && this._curBundleOtion.onComplete();
        true;
        var entryGame = this._curBundleOtion.EntryGame;
        var onComplete = this._curBundleOtion.onComplete;
        (null == entryGame || "" == entryGame && !onComplete) && cc.log("[BundleManager]", "\u672a\u627e\u5230\u9700\u8981\u81ea\u52a8\u6253\u5f00\u7684GameEntry\u548c\u52a0\u8f7d\u5b8c\u6bd5\u540e\u81ea\u6267\u884c\u65b9\u6cd5");
      };
      BundleManager.prototype.removeBundleByName = function(bundle) {
        var idx = this.loadedBundle.indexOf(bundle);
        if (-1 != idx) {
          AssetsManager_1.AssetsManager.Instance.removeBundle(this.loadedBundle[idx]);
          this.loadedBundle.splice(idx, 1);
        }
      };
      BundleManager._instance = null;
      return BundleManager;
    }();
    exports.BundleManager = BundleManager;
    var BundleOption = function() {
      function BundleOption(opt) {
        this.onComplete = null;
        this.Confirm = null;
        this.name = opt.name;
        this.bundleName = opt.bundleName;
        this.index = opt.index ? 0 : opt.index;
        this.onComplete = opt.onComplete;
        this.EntryGame = opt.entryGame;
        this.Confirm = opt.Confirm;
      }
      return BundleOption;
    }();
    exports.BundleOption = BundleOption;
    cc._RF.pop();
  }, {
    "../../Defineds/Events/EBundle": "EBundle",
    "../Assets/AssetsManager": "AssetsManager",
    "../Event/EventManager": "EventManager",
    "./../Entry/EntryManager": "EntryManager"
  } ],
  CacheManager: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "0a0e7uUurVMSrF2SzqVyfIk", "CacheManager");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.CacheManager = void 0;
    var RemoteCaches_1 = require("./RemoteCaches");
    var ResourceCache_1 = require("./ResourceCache");
    var CacheManager = function() {
      function CacheManager() {
        this._bundles = new Map();
        this._remoteCaches = new RemoteCaches_1.RemoteCaches();
      }
      Object.defineProperty(CacheManager, "Instance", {
        get: function() {
          return this._instance || (this._instance = new CacheManager());
        },
        enumerable: false,
        configurable: true
      });
      Object.defineProperty(CacheManager.prototype, "remoteCaches", {
        get: function() {
          return this._remoteCaches;
        },
        enumerable: false,
        configurable: true
      });
      CacheManager.prototype.removeBundle = function(bundle) {
        var bundleName = this.getBundleName(bundle);
        if (bundleName && this._bundles.has(bundleName)) {
          true;
          cc.log("[CacheManager]", "\u79fb\u9664bundle cache : " + bundleName);
          var data = this._bundles.get(bundleName);
          this._removeUnuseCaches();
          data.size > 0 && cc.error("[CacheManager]", "\u79fb\u9664bundle " + bundleName + " \u8fd8\u6709\u672a\u91ca\u653e\u7684\u7f13\u5b58");
          this._bundles.delete(bundleName);
        }
      };
      CacheManager.prototype._removeUnuseCaches = function() {
        this._bundles.forEach(function(value, key, origin) {
          value && value.removeUnuseCaches();
        });
      };
      CacheManager.prototype.getBundleName = function(bundle) {
        return "string" == typeof bundle ? bundle : bundle ? bundle.name : null;
      };
      CacheManager.prototype.get = function(bundle, path, isCheck) {
        void 0 === isCheck && (isCheck = true);
        var bundleName = this.getBundleName(bundle);
        if (bundleName && this._bundles.has(bundleName)) return this._bundles.get(bundleName).get(path, isCheck);
        return null;
      };
      CacheManager.prototype.remove = function(bundle, path) {
        var bundleName = this.getBundleName(bundle);
        if (bundleName && this._bundles.has(bundleName)) return this._bundles.get(bundleName).remove(path);
        return false;
      };
      CacheManager.prototype.removeWithInfo = function(info) {
        var fail = false;
        if (!info) {
          cc.error("[CacheManager]", "info is null");
          return fail;
        }
        if (!info.data) {
          cc.error("[CacheManager]", "info.data is null , bundle : " + info.bundle + " url : " + info.url);
          return fail;
        }
        if (Array.isArray(info.data)) {
          var isAllDelete = true;
          for (var i = 0; i < info.data.length; i++) {
            info.data[i].decRef();
            0 != info.data[i].refCount && (isAllDelete = false);
          }
          if (isAllDelete) {
            this.remove(info.bundle, info.url);
            fail = true;
          }
        } else {
          info.data.decRef();
          if (0 == info.data.refCount) {
            this.remove(info.bundle, info.url);
            fail = true;
          }
        }
        return fail;
      };
      CacheManager.prototype.set = function(bundle, path, data) {
        var bundleName = this.getBundleName(bundle);
        if (bundleName) if (this._bundles.has(bundleName)) this._bundles.get(bundleName).set(path, data); else {
          var cache = new ResourceCache_1.ResourceCache(bundleName);
          cache.set(path, data);
          this._bundles.set(bundleName, cache);
        }
      };
      CacheManager._instance = null;
      return CacheManager;
    }();
    exports.CacheManager = CacheManager;
    cc._RF.pop();
  }, {
    "./RemoteCaches": "RemoteCaches",
    "./ResourceCache": "ResourceCache"
  } ],
  Config: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "14ab1KBEshKXb5fYja1kS7j", "Config");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.Config = void 0;
    var Config = function() {
      function Config() {}
      Config.EnableMask = true;
      Config.defaultOpacity = 120;
      Config.defaultColor = "#000000";
      return Config;
    }();
    exports.Config = Config;
    cc._RF.pop();
  }, {} ],
  Const: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "5fe87HGK6tBc7PJwTFJjq+6", "Const");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.DYNAMIC_LOAD_GARBAGE = exports.BUNDLE_RESOURCES = void 0;
    exports.BUNDLE_RESOURCES = "resources";
    exports.DYNAMIC_LOAD_GARBAGE = "DYNAMIC_LOAD_GARBAGE";
    cc._RF.pop();
  }, {} ],
  Decorator: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "e049bVI2d9CG4LmVk80LobE", "Decorator");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.RegisterGameEntry = exports.ClassName = void 0;
    var EntryManager_1 = require("../Support/Entry/EntryManager");
    function ClassName() {
      return function(target) {
        var frameInfo = cc["_RF"].peek();
        var script = frameInfo.script;
        cc.js.setClassName(script, target);
      };
    }
    exports.ClassName = ClassName;
    function RegisterGameEntry(bundle) {
      void 0 === bundle && (bundle = "resources");
      return function(target) {
        target && EntryManager_1.EntryManager.addGameEntry(new target(), bundle);
      };
    }
    exports.RegisterGameEntry = RegisterGameEntry;
    cc._RF.pop();
  }, {
    "../Support/Entry/EntryManager": "EntryManager"
  } ],
  Dictionary: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "5a601d0QYpFUYHgv2LEKr3U", "Dictionary");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.Dictionary = void 0;
    var Dictionary = function() {
      function Dictionary() {
        this.keys = new Array();
        this.values = new Array();
      }
      Dictionary.prototype.setValue = function(key, value) {
        var index = this.keys.indexOf(key);
        if (-1 == index) {
          this.keys.push(key);
          this.values.push(value);
        } else this.values[index] = value;
      };
      Dictionary.prototype.getValue = function(key) {
        var index = this.keys.indexOf(key);
        return -1 == index ? null : this.values[index];
      };
      Dictionary.prototype.remove = function(key) {
        var index = this.keys.indexOf(key, 0);
        if (index > -1) {
          this.keys.splice(index, 1);
          this.values.splice(index, 1);
        }
      };
      Dictionary.prototype.hasKey = function(key) {
        return -1 != this.keys.indexOf(key);
      };
      Dictionary.prototype.getKeys = function() {
        return this.keys;
      };
      Dictionary.prototype.getValues = function() {
        return this.values;
      };
      Object.defineProperty(Dictionary.prototype, "count", {
        get: function() {
          return this.keys.length;
        },
        enumerable: false,
        configurable: true
      });
      return Dictionary;
    }();
    exports.Dictionary = Dictionary;
    cc._RF.pop();
  }, {} ],
  EBundle: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "9b081TRVwRJqomL8tWBq8cA", "EBundle");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.EBundle = void 0;
    var EBundle;
    (function(EBundle) {
      EBundle.LOAD_BUNDLE_FAIL = "LOAD_BUNDLE_FAIL";
      EBundle.BUNDLE_LOADING = "BUNDLE_LOADING";
    })(EBundle = exports.EBundle || (exports.EBundle = {}));
    cc._RF.pop();
  }, {} ],
  ENetEvent: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "28052WgzThPjqMXc0f+8Fm/", "ENetEvent");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.ENetEvent = void 0;
    var ENetEvent = function() {
      function ENetEvent() {}
      ENetEvent.ON_OPEN = "NetEvent_ON_OPEN";
      ENetEvent.ON_CLOSE = "NetEvent_ON_CLOSE";
      ENetEvent.ON_ERROR = "NetEvent_ON_ERROR";
      ENetEvent.ON_CUSTOM_CLOSE = "NetEvent_ON_CUSTOM_CLOSE";
      return ENetEvent;
    }();
    exports.ENetEvent = ENetEvent;
    cc._RF.pop();
  }, {} ],
  EUIManager: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "356284ywm9I24LVgvIp26sQ", "EUIManager");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.EUIManager = void 0;
    var EUIManager = function() {
      function EUIManager() {}
      EUIManager.SHOW_LOADING = "SHOW_LOADING";
      EUIManager.HIDE_LOADING = "HIDE_LOADING";
      return EUIManager;
    }();
    exports.EUIManager = EUIManager;
    cc._RF.pop();
  }, {} ],
  EUpdater: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "288b7uQ91RN15ZvNHZFpw+r", "EUpdater");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.EUpdater = void 0;
    var EUpdater;
    (function(EUpdater) {
      EUpdater.HOTUPDATE_DOWNLOAD = "HOTUPDATE_DOWNLOAD";
    })(EUpdater = exports.EUpdater || (exports.EUpdater = {}));
    cc._RF.pop();
  }, {} ],
  EntryManager: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "288f5IVdBlDeYtTeYpR/qXQ", "EntryManager");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.EntryManager = void 0;
    var GameEntry_1 = require("./GameEntry");
    var EntryManager = function() {
      function EntryManager() {}
      EntryManager.addExclude = function(exclude) {
        var name = "";
        name = exclude instanceof GameEntry_1.GameEntry ? cc.js.getClassName(exclude) : exclude;
        -1 == this._exclude.indexOf(name) && this._exclude.push(name);
      };
      EntryManager.addGameEntry = function(m, bundle) {
        false;
        var name = cc.js.getClassName(m);
        if (!this._gameEntrys[name]) {
          m["_bundle"] = bundle;
          this._gameEntrys[name] = m;
        }
        true;
        cc.log("[EntryManager]", "GameEntry\u6dfb\u52a0", name);
      };
      EntryManager.getGameEntry = function(name) {
        if (this._gameEntrys[name]) return this._gameEntrys[name];
        return null;
      };
      EntryManager.stopGameEntry = function(gameEntry) {
        var entryName = "";
        entryName = "string" == typeof gameEntry ? gameEntry : cc.js.getClassName(gameEntry);
        this._gameEntrys[entryName] && this._gameEntrys[entryName].exitGameEntry();
      };
      EntryManager.startGameEntry = function(gameEntry) {
        var entryName = "";
        entryName = "string" == typeof gameEntry ? gameEntry : cc.js.getClassName(gameEntry);
        for (var key in this._gameEntrys) {
          if (key == gameEntry) {
            this._gameEntrys[key].runGameEntry();
            continue;
          }
          -1 == this._exclude.indexOf(entryName) && this._gameEntrys[key].exitGameEntry();
        }
      };
      EntryManager._gameEntrys = {};
      EntryManager._exclude = [];
      return EntryManager;
    }();
    exports.EntryManager = EntryManager;
    cc._RF.pop();
  }, {
    "./GameEntry": "GameEntry"
  } ],
  EventComponent: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "57b02/oxFlGpr0Y4a7lB0eU", "EventComponent");
    "use strict";
    var __extends = this && this.__extends || function() {
      var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function(d, b) {
          d.__proto__ = b;
        } || function(d, b) {
          for (var p in b) b.hasOwnProperty(p) && (d[p] = b[p]);
        };
        return extendStatics(d, b);
      };
      return function(d, b) {
        extendStatics(d, b);
        function __() {
          this.constructor = d;
        }
        d.prototype = null === b ? Object.create(b) : (__.prototype = b.prototype, new __());
      };
    }();
    var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : null === desc ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if ("object" === typeof Reflect && "function" === typeof Reflect.decorate) r = Reflect.decorate(decorators, target, key, desc); else for (var i = decorators.length - 1; i >= 0; i--) (d = decorators[i]) && (r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r);
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var EventManager_1 = require("../Support/Event/EventManager");
    var ccclass = cc._decorator.ccclass;
    var addEvents = Symbol("addEvents");
    var EventComponent = function(_super) {
      __extends(EventComponent, _super);
      function EventComponent() {
        var _this = null !== _super && _super.apply(this, arguments) || this;
        _this._events = [];
        return _this;
      }
      EventComponent.prototype.addEvents = function() {};
      EventComponent.prototype.removeEvenrs = function() {
        EventManager_1.EventManager.removeEvent(this);
      };
      EventComponent.prototype.UIEvent = function(type, fn) {
        this._events.push({
          type: type,
          fn: fn
        });
      };
      EventComponent.prototype.NetEvent = function() {};
      EventComponent.prototype.onLoad = function() {
        this.addEvents();
        this[addEvents]();
      };
      EventComponent.prototype.onDestroy = function() {
        this.removeEvenrs();
      };
      EventComponent.prototype[addEvents] = function() {
        for (var i = 0; i < this._events.length; i++) {
          var event = this._events.pop();
          EventManager_1.EventManager.addEvent(this, event.type, event.fn);
        }
      };
      EventComponent = __decorate([ ccclass ], EventComponent);
      return EventComponent;
    }(cc.Component);
    exports.default = EventComponent;
    cc._RF.pop();
  }, {
    "../Support/Event/EventManager": "EventManager"
  } ],
  EventDispather: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "f8592/R6/1BAryRWKwRp/aD", "EventDispather");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.EventDispather = void 0;
    var Dictionary_1 = require("../../Libs/Dictionary");
    var EventDispather = function() {
      function EventDispather() {
        this.events = new Dictionary_1.Dictionary();
      }
      EventDispather.prototype.addEvent = function(obj, type, fun) {
        this.events.hasKey(obj) || this.events.setValue(obj, {
          length: 0
        });
        var o = this.events.getValue(obj);
        if (void 0 == o[type]) {
          o[type] = [];
          o.length++;
        }
        var funs = o[type];
        -1 == funs.indexOf(fun) && funs.push(fun);
      };
      EventDispather.prototype.removeEvent = function(obj, type, fun) {
        if (!this.events.hasKey(obj)) return;
        var o = this.events.getValue(obj);
        var funs;
        if (null != type) {
          if (!o[type]) return;
          funs = o[type];
          if (null != fun) {
            var index = funs.indexOf(fun);
            index > -1 && funs.splice(index, 1);
          } else {
            funs = o[type];
            while (funs.length > 0) funs.shift();
          }
          if (0 == funs.length) {
            o.length--;
            delete o[type];
          }
        } else for (var s in o) {
          if ("length" == s) continue;
          funs = o[s];
          o.length--;
          while (funs.length > 0) funs.shift();
        }
        o.length <= 0 && this.events.remove(obj);
      };
      EventDispather.prototype.dispatchEvent = function(evt) {
        var type = evt.type;
        var objs = this.events.getKeys();
        var o, obj, funs;
        for (var i = 0; i < objs.length; i++) {
          obj = objs[i];
          o = this.events.getValue(obj);
          if (!o[type]) continue;
          funs = o[type];
          for (var j = 0; j < funs.length; j++) 0 == funs[j].length ? funs[j].call(obj) : funs[j].call(obj, evt);
        }
      };
      return EventDispather;
    }();
    exports.EventDispather = EventDispather;
    cc._RF.pop();
  }, {
    "../../Libs/Dictionary": "Dictionary"
  } ],
  EventManager: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "379f37IQBpJ6bRv7tgjU+im", "EventManager");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.EventManager = void 0;
    var EventDispather_1 = require("./EventDispather");
    var EventOption_1 = require("./EventOption");
    var EventManager = function() {
      function EventManager() {}
      EventManager.addEvent = function(obj, type, fun) {
        this.dispather.addEvent(obj, type, fun);
      };
      EventManager.removeEvent = function(obj, type, fun) {
        this.dispather.removeEvent(obj, type, fun);
      };
      EventManager.dispatchEventWith = function(type, data) {
        this.dispatchEvent(new EventOption_1.EventOption(type, data));
      };
      EventManager.dispatchEvent = function(evt) {
        this.dispather.dispatchEvent(evt);
      };
      EventManager.dispather = new EventDispather_1.EventDispather();
      return EventManager;
    }();
    exports.EventManager = EventManager;
    window["dispatch"] = function(type, data) {
      EventManager.dispatchEventWith(type, data);
    };
    cc._RF.pop();
  }, {
    "./EventDispather": "EventDispather",
    "./EventOption": "EventOption"
  } ],
  EventOption: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "2c0e1PtO7RNMrDG9I7AfF0v", "EventOption");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.EventOption = void 0;
    var EventOption = function() {
      function EventOption(type, data) {
        this._data = null;
        this._type = null;
        this._data = data;
        this._type = type;
      }
      Object.defineProperty(EventOption.prototype, "data", {
        get: function() {
          return this._data;
        },
        enumerable: false,
        configurable: true
      });
      Object.defineProperty(EventOption.prototype, "type", {
        get: function() {
          return this._type;
        },
        enumerable: false,
        configurable: true
      });
      return EventOption;
    }();
    exports.EventOption = EventOption;
    cc._RF.pop();
  }, {} ],
  Framework: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "0fa4blm3sBPtrY0alt4/j+q", "Framework");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.Framework = void 0;
    var AssetsManager_1 = require("./Support/Assets/AssetsManager");
    var CacheManager_1 = require("./Support/Assets/CacheManager");
    var BundleManager_1 = require("./Support/Bundler/BundleManager");
    var EntryManager_1 = require("./Support/Entry/EntryManager");
    var EventManager_1 = require("./Support/Event/EventManager");
    var HotUpdateManger_1 = require("./Support/HotUpdate/HotUpdateManger");
    var LayerManager_1 = require("./Support/Layer/LayerManager");
    var LocalStorage_1 = require("./Support/LocalStorage/LocalStorage");
    var ServiceManager_1 = require("./Support/NetWork/Manager/ServiceManager");
    var UIManager_1 = require("./Support/UIView/UIManager");
    var Framework = function() {
      function Framework() {}
      Object.defineProperty(Framework.prototype, "uiManager", {
        get: function() {
          return UIManager_1.UIManager.Instance;
        },
        enumerable: false,
        configurable: true
      });
      Object.defineProperty(Framework.prototype, "layerManager", {
        get: function() {
          return LayerManager_1.LayerManager.Instance;
        },
        enumerable: false,
        configurable: true
      });
      Object.defineProperty(Framework.prototype, "hotupdateManager", {
        get: function() {
          return HotUpdateManger_1.HotUpdateManager;
        },
        enumerable: false,
        configurable: true
      });
      Object.defineProperty(Framework.prototype, "bundleManager", {
        get: function() {
          return BundleManager_1.BundleManager.Instance;
        },
        enumerable: false,
        configurable: true
      });
      Object.defineProperty(Framework.prototype, "enteyManager", {
        get: function() {
          return EntryManager_1.EntryManager;
        },
        enumerable: false,
        configurable: true
      });
      Object.defineProperty(Framework.prototype, "eventManager", {
        get: function() {
          return EventManager_1.EventManager;
        },
        enumerable: false,
        configurable: true
      });
      Object.defineProperty(Framework.prototype, "assetsManager", {
        get: function() {
          return AssetsManager_1.AssetsManager.Instance;
        },
        enumerable: false,
        configurable: true
      });
      Object.defineProperty(Framework.prototype, "cacheManager", {
        get: function() {
          return CacheManager_1.CacheManager;
        },
        enumerable: false,
        configurable: true
      });
      Object.defineProperty(Framework.prototype, "localStorage", {
        get: function() {
          return LocalStorage_1.LocalStorage.Instance;
        },
        enumerable: false,
        configurable: true
      });
      Object.defineProperty(Framework.prototype, "serviceManager", {
        get: function() {
          return ServiceManager_1.ServiceManager.Instance;
        },
        enumerable: false,
        configurable: true
      });
      return Framework;
    }();
    exports.Framework = Framework;
    cc._RF.pop();
  }, {
    "./Support/Assets/AssetsManager": "AssetsManager",
    "./Support/Assets/CacheManager": "CacheManager",
    "./Support/Bundler/BundleManager": "BundleManager",
    "./Support/Entry/EntryManager": "EntryManager",
    "./Support/Event/EventManager": "EventManager",
    "./Support/HotUpdate/HotUpdateManger": "HotUpdateManger",
    "./Support/Layer/LayerManager": "LayerManager",
    "./Support/LocalStorage/LocalStorage": "LocalStorage",
    "./Support/NetWork/Manager/ServiceManager": "ServiceManager",
    "./Support/UIView/UIManager": "UIManager"
  } ],
  GameEntry: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "dc7aaVVQApB76YxMQoQ4q6j", "GameEntry");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.GameEntry = void 0;
    var EventManager_1 = require("../Event/EventManager");
    var UIManager_1 = require("../UIView/UIManager");
    var GameEntry = function() {
      function GameEntry() {
        this._bundle = "";
        this._isRun = false;
        this._modules = [];
      }
      GameEntry.prototype.bundle = function() {
        return this._bundle;
      };
      Object.defineProperty(GameEntry.prototype, "Modules", {
        get: function() {
          return this._modules;
        },
        enumerable: false,
        configurable: true
      });
      GameEntry.prototype.addModules = function(opt) {
        if (opt instanceof Array) for (var i = 0; i < opt.length; i++) this._addModule(opt[i]); else if (opt instanceof Object) for (var key in opt) this._addModule(opt[key]); else this._addModule(opt);
      };
      GameEntry.prototype.closeModule = function(opt) {
        "string" == typeof opt ? UIManager_1.UIManager.Instance.close(opt) : UIManager_1.UIManager.Instance.close(opt.component);
      };
      GameEntry.prototype._addModule = function(opt) {
        var _this = this;
        this._modules.push(opt.component);
        var func = null;
        "string" == typeof opt.onShowedFuncName ? this._checkFuncExist(opt.onShowedFuncName) && (func = this[opt.onShowedFuncName].bind(this)) : func = opt.onShowedFuncName;
        EventManager_1.EventManager.addEvent(this, opt.event, function(dat) {
          UIManager_1.UIManager.Instance.openView({
            ModuelConfig: {
              component: opt.component,
              bundle: _this.bundle(),
              layer: opt.layer,
              zIndex: opt.zIndex,
              name: opt.name
            },
            data: dat.data,
            onShowed: func
          });
        });
      };
      GameEntry.prototype._checkFuncExist = function(key) {
        return Reflect ? Reflect.has(this, key) : this.__proto__.hasOwnProperty(key);
      };
      GameEntry.prototype.initEntry = function() {};
      GameEntry.prototype.initViews = function() {};
      GameEntry.prototype.addEvents = function() {};
      GameEntry.prototype.removeEvents = function() {
        EventManager_1.EventManager.removeEvent(this);
      };
      GameEntry.prototype.closeViews = function() {};
      GameEntry.prototype.runGameEntry = function() {
        if (this._isRun) return;
        this._isRun = true;
        this._modules.length = 0;
        this.initEntry();
        this.initViews();
        this.addEvents();
      };
      GameEntry.prototype.exitGameEntry = function() {
        if (!this._isRun) return;
        this._isRun = false;
        this.removeEvents();
        this.closeViews();
      };
      return GameEntry;
    }();
    exports.GameEntry = GameEntry;
    cc._RF.pop();
  }, {
    "../Event/EventManager": "EventManager",
    "../UIView/UIManager": "UIManager"
  } ],
  GameItemBinder: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "932aaMM7XVLaZiqYH3NxiUd", "GameItemBinder");
    "use strict";
    var __extends = this && this.__extends || function() {
      var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function(d, b) {
          d.__proto__ = b;
        } || function(d, b) {
          for (var p in b) b.hasOwnProperty(p) && (d[p] = b[p]);
        };
        return extendStatics(d, b);
      };
      return function(d, b) {
        extendStatics(d, b);
        function __() {
          this.constructor = d;
        }
        d.prototype = null === b ? Object.create(b) : (__.prototype = b.prototype, new __());
      };
    }();
    var __spreadArrays = this && this.__spreadArrays || function() {
      for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
      for (var r = Array(s), k = 0, i = 0; i < il; i++) for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, 
      k++) r[k] = a[j];
      return r;
    };
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.GameItemBinder = void 0;
    var ModuleBinder_1 = require("../../Framework/Component/ModuleBinder");
    var BundleManager_1 = require("../../Framework/Support/Bundler/BundleManager");
    var GameItemBinder = function(_super) {
      __extends(GameItemBinder, _super);
      function GameItemBinder() {
        var _this = null !== _super && _super.apply(this, arguments) || this;
        _this.data = null;
        _this._title = null;
        _this._process_sprite = null;
        _this._process_title = null;
        return _this;
      }
      GameItemBinder.prototype.setNode = function(node) {
        var args = [];
        for (var _i = 1; _i < arguments.length; _i++) args[_i - 1] = arguments[_i];
        this.data = args[0];
        _super.prototype.setNode.apply(this, __spreadArrays([ node ], args));
      };
      GameItemBinder.prototype.initViews = function() {
        this.node.active = true;
        this._title = this.find("title").getComponent(cc.Label);
        this._process_sprite = this.find("process");
        this._process_title = this.find("process_text").getComponent(cc.Label);
        this._process_sprite.active = false;
        this._process_sprite.height = 204;
        this._process_title.string = "";
        this._process_title.node.active = false;
        this._title.string = this.data.name;
        manager.isBrower && this.node.on("click", this._joinSubGame, this);
      };
      GameItemBinder.prototype._checkStatus = function() {
        true;
      };
      GameItemBinder.prototype._joinSubGame = function() {
        manager.bundleManager.entryBundle(new BundleManager_1.BundleOption({
          name: this.data.name,
          bundleName: this.data.bundleName,
          entryGame: this.data.entryName
        }));
      };
      GameItemBinder.prototype.addEvents = function() {};
      return GameItemBinder;
    }(ModuleBinder_1.ModuleBinder);
    exports.GameItemBinder = GameItemBinder;
    cc._RF.pop();
  }, {
    "../../Framework/Component/ModuleBinder": "ModuleBinder",
    "../../Framework/Support/Bundler/BundleManager": "BundleManager"
  } ],
  GameList: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "f07f1+ldZtKlbh/7uvz22Mg", "GameList");
    cc._RF.pop();
  }, {} ],
  GameModel: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "7095bWJ26FD3ICDn4EqGVbv", "GameModel");
    "use strict";
    var __extends = this && this.__extends || function() {
      var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function(d, b) {
          d.__proto__ = b;
        } || function(d, b) {
          for (var p in b) b.hasOwnProperty(p) && (d[p] = b[p]);
        };
        return extendStatics(d, b);
      };
      return function(d, b) {
        extendStatics(d, b);
        function __() {
          this.constructor = d;
        }
        d.prototype = null === b ? Object.create(b) : (__.prototype = b.prototype, new __());
      };
    }();
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.GameModel = void 0;
    var InjectData_1 = require("../../Framework/Libs/InjectData");
    var GameModel = function(_super) {
      __extends(GameModel, _super);
      function GameModel() {
        return null !== _super && _super.apply(this, arguments) || this;
      }
      return GameModel;
    }(InjectData_1.InjectData);
    exports.GameModel = GameModel;
    cc._RF.pop();
  }, {
    "../../Framework/Libs/InjectData": "InjectData"
  } ],
  HotUpdateEnums: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "c68d948Uh5CxYFGdQYv+6po", "HotUpdateEnums");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.HotUpdateEnums = void 0;
    var HotUpdateEnums;
    (function(HotUpdateEnums) {
      var Code;
      (function(Code) {
        Code[Code["ERROR_NO_LOCAL_MANIFEST"] = 0] = "ERROR_NO_LOCAL_MANIFEST";
        Code[Code["ERROR_DOWNLOAD_MANIFEST"] = 1] = "ERROR_DOWNLOAD_MANIFEST";
        Code[Code["ERROR_PARSE_MANIFEST"] = 2] = "ERROR_PARSE_MANIFEST";
        Code[Code["NEW_VERSION_FOUND"] = 3] = "NEW_VERSION_FOUND";
        Code[Code["ALREADY_UP_TO_DATE"] = 4] = "ALREADY_UP_TO_DATE";
        Code[Code["UPDATE_PROGRESSION"] = 5] = "UPDATE_PROGRESSION";
        Code[Code["ASSET_UPDATED"] = 6] = "ASSET_UPDATED";
        Code[Code["ERROR_UPDATING"] = 7] = "ERROR_UPDATING";
        Code[Code["UPDATE_FINISHED"] = 8] = "UPDATE_FINISHED";
        Code[Code["UPDATE_FAILED"] = 9] = "UPDATE_FAILED";
        Code[Code["ERROR_DECOMPRESS"] = 10] = "ERROR_DECOMPRESS";
        Code[Code["CHECKING"] = 11] = "CHECKING";
      })(Code = HotUpdateEnums.Code || (HotUpdateEnums.Code = {}));
      var State;
      (function(State) {
        State[State["UNINITED"] = 0] = "UNINITED";
        State[State["UNCHECKED"] = 1] = "UNCHECKED";
        State[State["PREDOWNLOAD_VERSION"] = 2] = "PREDOWNLOAD_VERSION";
        State[State["DOWNLOADING_VERSION"] = 3] = "DOWNLOADING_VERSION";
        State[State["VERSION_LOADED"] = 4] = "VERSION_LOADED";
        State[State["PREDOWNLOAD_MANIFEST"] = 5] = "PREDOWNLOAD_MANIFEST";
        State[State["DOWNLOADING_MANIFEST"] = 6] = "DOWNLOADING_MANIFEST";
        State[State["MANIFEST_LOADED"] = 7] = "MANIFEST_LOADED";
        State[State["NEED_UPDATE"] = 8] = "NEED_UPDATE";
        State[State["READY_TO_UPDATE"] = 9] = "READY_TO_UPDATE";
        State[State["UPDATING"] = 10] = "UPDATING";
        State[State["UNZIPPING"] = 11] = "UNZIPPING";
        State[State["UP_TO_DATE"] = 12] = "UP_TO_DATE";
        State[State["FAIL_TO_UPDATE"] = 13] = "FAIL_TO_UPDATE";
        State[State["TRY_DOWNLOAD_FAILED_ASSETS"] = 14] = "TRY_DOWNLOAD_FAILED_ASSETS";
      })(State = HotUpdateEnums.State || (HotUpdateEnums.State = {}));
    })(HotUpdateEnums = exports.HotUpdateEnums || (exports.HotUpdateEnums = {}));
    cc._RF.pop();
  }, {} ],
  HotUpdateManger: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "9a514Uxvo5EdLCKtAfS1rVy", "HotUpdateManger");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.HotUpdateManager = void 0;
    var Updater_1 = require("./Updater");
    var HotUpdateManager = function() {
      function HotUpdateManager() {}
      Object.defineProperty(HotUpdateManager, "isBrowser", {
        get: function() {
          return cc.sys.platform == cc.sys.WECHAT_GAME || cc.sys.isBrowser;
        },
        enumerable: false,
        configurable: true
      });
      HotUpdateManager.getUpdater = function(key) {
        if (this._updaters.has(key)) return this._updaters.get(key);
        return null;
      };
      HotUpdateManager.checkUpdate = function(callback, option) {
        void 0 === option && (option = null);
        this.isBrowser ? this.checkUpdateWeb(callback) : this.checkUpdateNative(option, callback);
      };
      HotUpdateManager.checkUpdateWeb = function(updateCallback) {
        var _this = this;
        this._updaters.set("webview", new Updater_1.Updater(null, updateCallback, function() {
          _this._updaters.delete("webview");
        }));
      };
      HotUpdateManager.checkUpdateNative = function(option, updateCallback) {
        var _this = this;
        if (this._updaters.size >= 2 && !this.isBrowser) {
          cc.log("[HotUpdateManager]", "\u5f53\u524d\u5df2\u8fbe\u6700\u5927\u4efb\u52a1\u6570");
          return;
        }
        this._updaters.set(option.name, new Updater_1.Updater(option, updateCallback, function() {
          _this._updaters.delete(option.name);
        }));
      };
      HotUpdateManager.startUpdate = function(name) {
        this._updaters.has(name) && this._updaters.get(name).runHotUpdate();
      };
      HotUpdateManager.tryUpdate = function(name) {
        this._updaters.has(name) && this._updaters.get(name).downloadFailedAssets();
      };
      HotUpdateManager._updaters = new Map();
      return HotUpdateManager;
    }();
    exports.HotUpdateManager = HotUpdateManager;
    cc._RF.pop();
  }, {
    "./Updater": "Updater"
  } ],
  ICommonService: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "499a92xi+5BfKIqXNcrqPZc", "ICommonService");
    "use strict";
    var __extends = this && this.__extends || function() {
      var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function(d, b) {
          d.__proto__ = b;
        } || function(d, b) {
          for (var p in b) b.hasOwnProperty(p) && (d[p] = b[p]);
        };
        return extendStatics(d, b);
      };
      return function(d, b) {
        extendStatics(d, b);
        function __() {
          this.constructor = d;
        }
        d.prototype = null === b ? Object.create(b) : (__.prototype = b.prototype, new __());
      };
    }();
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.ICommonService = void 0;
    var Macro_1 = require("../../../Config/Macro");
    var Service_1 = require("./Service");
    var ICommonService = function(_super) {
      __extends(ICommonService, _super);
      function ICommonService() {
        var _this = null !== _super && _super.apply(this, arguments) || this;
        _this._maxEnterBackgroundTime = Macro_1.Macro.MAX_INBACKGROUND_TIME;
        _this._backgroundTimeOutId = -1;
        return _this;
      }
      Object.defineProperty(ICommonService.prototype, "maxEnterBackgroundTime", {
        get: function() {
          return this._maxEnterBackgroundTime;
        },
        set: function(value) {
          (value < Macro_1.Macro.MIN_INBACKGROUND_TIME || value > Macro_1.Macro.MAX_INBACKGROUND_TIME) && (value = Macro_1.Macro.MIN_INBACKGROUND_TIME);
          cc.log(this.serviceName, "maxEnterBackgroundTime " + value);
          this._maxEnterBackgroundTime = value;
        },
        enumerable: false,
        configurable: true
      });
      ICommonService.prototype.connect = function() {};
      ICommonService.prototype.sendHeartbeat = function() {
        this.heartbeat ? this.send(new this.heartbeat()) : cc.error("\u8bf7\u5148\u8bbe\u7f6e\u5fc3\u8df3\u89e3\u6790\u7c7b\u578b");
      };
      ICommonService.prototype.onHeartbeatTimeOut = function() {
        _super.prototype.onHeartbeatTimeOut.call(this);
      };
      ICommonService.prototype.onError = function(ev) {
        _super.prototype.onError.call(this, ev);
      };
      ICommonService.prototype.onClose = function(ev) {
        _super.prototype.onClose.call(this, ev);
      };
      ICommonService.prototype.onEnterBackground = function() {};
      ICommonService.prototype.onEnterForgeground = function(inBackgroundTime) {
        if (-1 != this._backgroundTimeOutId) {
          cc.log("\u6e05\u9664\u8fdb\u5165\u540e\u53f0\u7684\u8d85\u65f6\u5173\u95ed\u7f51\u7edc\u5b9a\u65f6\u5668");
          clearTimeout(this._backgroundTimeOutId);
          cc.log("\u5728\u540e\u53f0\u65f6\u95f4" + inBackgroundTime + " , \u6700\u5927\u65f6\u95f4\u4e3a: " + this.maxEnterBackgroundTime);
        }
      };
      return ICommonService;
    }(Service_1.Service);
    exports.ICommonService = ICommonService;
    cc._RF.pop();
  }, {
    "../../../Config/Macro": "Macro",
    "./Service": "Service"
  } ],
  IDestroy: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "a47e7sZIPZEOIJC49uupHVm", "IDestroy");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    cc._RF.pop();
  }, {} ],
  IGameEventInterface: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "8ee0aaPvChFnaWwT2uaG9zA", "IGameEventInterface");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    cc._RF.pop();
  }, {} ],
  IListenerData: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "ace53bMC6dN16xbjLha5B0B", "IListenerData");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    cc._RF.pop();
  }, {} ],
  IMessage: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "0acddpBjCRNZ7kiU9N+U5Vc", "IMessage");
    "use strict";
    var __extends = this && this.__extends || function() {
      var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function(d, b) {
          d.__proto__ = b;
        } || function(d, b) {
          for (var p in b) b.hasOwnProperty(p) && (d[p] = b[p]);
        };
        return extendStatics(d, b);
      };
      return function(d, b) {
        extendStatics(d, b);
        function __() {
          this.constructor = d;
        }
        d.prototype = null === b ? Object.create(b) : (__.prototype = b.prototype, new __());
      };
    }();
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.Message = exports.Codec = exports.IMessage = void 0;
    var IMessage = function() {
      function IMessage() {}
      return IMessage;
    }();
    exports.IMessage = IMessage;
    var Codec = function(_super) {
      __extends(Codec, _super);
      function Codec() {
        return null !== _super && _super.apply(this, arguments) || this;
      }
      return Codec;
    }(IMessage);
    exports.Codec = Codec;
    var Message = function(_super) {
      __extends(Message, _super);
      function Message() {
        return null !== _super && _super.apply(this, arguments) || this;
      }
      return Message;
    }(IMessage);
    exports.Message = Message;
    cc._RF.pop();
  }, {} ],
  IModuleConfig: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "eadf4g1l4pK2bxSpdSjqi7C", "IModuleConfig");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    cc._RF.pop();
  }, {} ],
  IModuleDataLoadData: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "f1d053Q6RdM9qIpMTlKRDgM", "IModuleDataLoadData");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    cc._RF.pop();
  }, {} ],
  IModuleOption: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "0f7b2+O14xCfIt7K1y6ZPDr", "IModuleOption");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    cc._RF.pop();
  }, {} ],
  IResource: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "fd133hBlOZDqYsH37xoLaMF", "IResource");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.IResource = void 0;
    var ResourceCacheStatus_1 = require("../Enums/ResourceCacheStatus");
    var ResourceType_1 = require("../Enums/ResourceType");
    var IResource;
    (function(IResource) {
      var ResourceCacheData = function() {
        function ResourceCacheData() {
          this.isLoaded = false;
          this.data = null;
          this.info = new ResourceInfo();
          this.status = ResourceCacheStatus_1.ResourceCacheStatus.NONE;
          this.getCb = [];
          this.finishCb = [];
        }
        ResourceCacheData.prototype.doGet = function(data) {
          for (var i = 0; i < this.getCb.length; i++) this.getCb[i] && this.getCb[i](data);
          this.getCb = [];
        };
        ResourceCacheData.prototype.doFinish = function(data) {
          for (var i = 0; i < this.finishCb.length; i++) this.finishCb[i] && this.finishCb[i](data);
          this.finishCb = [];
        };
        Object.defineProperty(ResourceCacheData.prototype, "isInvalid", {
          get: function() {
            return this.isLoaded && this.data && !cc.isValid(this.data);
          },
          enumerable: false,
          configurable: true
        });
        return ResourceCacheData;
      }();
      IResource.ResourceCacheData = ResourceCacheData;
      var ResourceInfo = function() {
        function ResourceInfo() {
          this.url = "";
          this.type = null;
          this.data = null;
          this.retain = false;
          this.bundle = null;
          this.resourceType = ResourceType_1.ResourceType.Local;
        }
        return ResourceInfo;
      }();
      IResource.ResourceInfo = ResourceInfo;
    })(IResource = exports.IResource || (exports.IResource = {}));
    cc._RF.pop();
  }, {
    "../Enums/ResourceCacheStatus": "ResourceCacheStatus",
    "../Enums/ResourceType": "ResourceType"
  } ],
  IUIClass: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "3f195qOtvxG2aswFzk4/ZMN", "IUIClass");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    cc._RF.pop();
  }, {} ],
  IUpdater: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "db142MASABGyJk5i0aJ+W5m", "IUpdater");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    cc._RF.pop();
  }, {} ],
  InjectData: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "e9b25+amt5L44F34SixOe6R", "InjectData");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.InjectData = void 0;
    var InjectObjectUtility_1 = require("./InjectObjectUtility");
    var InjectData = function() {
      function InjectData() {}
      InjectData.prototype.update = function(data) {
        this.analysis(data);
      };
      InjectData.prototype.analysis = function(data) {
        var cystomPropertys = [];
        for (var _i = 1; _i < arguments.length; _i++) cystomPropertys[_i - 1] = arguments[_i];
        InjectObjectUtility_1.InjectObjectUtility.Analysis(this, this, data, this.customSetProperty, this.unOwnSetProperty, cystomPropertys);
      };
      InjectData.prototype.unOwnSetProperty = function(thisObj, data, property) {};
      InjectData.prototype.customSetProperty = function(thisObj, data, property) {
        if (Reflect.has(this, property)) {
          var inject = Reflect.get(this, property);
          inject instanceof InjectData && inject.update(data[property]);
        } else this.unOwnSetProperty(thisObj, data, property);
      };
      return InjectData;
    }();
    exports.InjectData = InjectData;
    cc._RF.pop();
  }, {
    "./InjectObjectUtility": "InjectObjectUtility"
  } ],
  InjectObjectUtility: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "6e498B2GCFA+K2eAPnWG3j6", "InjectObjectUtility");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.InjectObjectUtility = void 0;
    var InjectData_1 = require("./InjectData");
    var InjectObjectUtility = function() {
      function InjectObjectUtility() {}
      InjectObjectUtility.SetProperty = function(target, source) {
        for (var property in source) target[property] = source[property];
      };
      InjectObjectUtility.Analysis = function(thisObj, target, source, customSetProperty, unOwnProperty, customPropertys) {
        if (null == source) return;
        for (var property in source) Reflect.has(target, property) ? 0 == customPropertys.length || -1 == customPropertys.indexOf(property) ? target[property] != source[property] && (target[property] = source[property]) : null != customSetProperty && customSetProperty.call(thisObj, target, source, property) : null != unOwnProperty && unOwnProperty.call(thisObj, target, source, property);
      };
      InjectObjectUtility.CloneObject = function(source) {};
      InjectObjectUtility.ToArray = function(v) {
        var arr = [];
        for (var i = 0; i < v.length; i++) arr[i] = v[i];
        return arr;
      };
      InjectObjectUtility.TransformObjectVector = function(data, clz) {
        if (data && Reflect.has(data, "length")) {
          var arr = [];
          for (var i = 0; i < data.length; i++) if (clz == String || clz == Number || clz == Boolean) arr.push(data[i]); else {
            var v = new clz();
            v instanceof InjectData_1.InjectData ? v.update(data[i]) : this.Analysis(this, v, data[i], this.CustomSetProperty, this.CustomSetProperty, []);
            arr.push(v);
          }
          return arr;
        }
        return [];
      };
      InjectObjectUtility.CustomSetProperty = function(thisObj, data, property) {};
      return InjectObjectUtility;
    }();
    exports.InjectObjectUtility = InjectObjectUtility;
    cc._RF.pop();
  }, {
    "./InjectData": "InjectData"
  } ],
  LayerManager: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "ffb9097EUpO04b0j8Vcqjk6", "LayerManager");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.LayerManager = void 0;
    var Macro_1 = require("../../Config/Macro");
    var Layer_1 = require("../../Defineds/Enums/Layer");
    var LayerManager = function() {
      function LayerManager() {
        this._layers = [];
        Macro_1.Macro.EnableLayerManager && this._creatLayers();
      }
      Object.defineProperty(LayerManager, "Instance", {
        get: function() {
          return this._instance || (this._instance = new LayerManager());
        },
        enumerable: false,
        configurable: true
      });
      LayerManager.prototype._creatLayers = function() {
        var _a;
        this._layers.length = 0;
        var parentNode = null === (_a = cc.director.getScene()) || void 0 === _a ? void 0 : _a.getChildByName("Canvas");
        var size = cc.view.getCanvasSize();
        for (var i = 0; i < Layer_1.Layer.GameLayerNames.length; i++) {
          var node = parentNode.getChildByName(Layer_1.Layer.GameLayerNames[i]);
          if (null == node) {
            node = new cc.Node();
            node.setContentSize(size);
            parentNode.addChild(node);
            this._addWidget(node);
          }
          node.name = Layer_1.Layer.GameLayerNames[i];
          this._layers.push(node);
        }
      };
      LayerManager.prototype._addWidget = function(view) {
        var widget = view.addComponent(cc.Widget);
        if (widget) {
          widget.isAlignHorizontalCenter = true;
          widget.horizontalCenter = 0;
          widget.isAlignVerticalCenter = true;
          widget.verticalCenter = 0;
        }
      };
      LayerManager.prototype.getLayer = function(layerIndex) {
        return Macro_1.Macro.EnableLayerManager ? this._layers[layerIndex] : this.getMainNode();
      };
      LayerManager.prototype.getMainNode = function() {
        return this.getCanvas();
      };
      LayerManager.prototype.getCanvasComponent = function() {
        var rootScene = cc.director.getScene();
        var root = rootScene.getChildByName("Canvas");
        return root.getComponent(cc.Canvas);
      };
      LayerManager.prototype.getCanvas = function() {
        var rootScene = cc.director.getScene();
        if (!rootScene) {
          true;
          cc.error("[LayerManager]", "\u5f53\u524d\u573a\u666f\u4e3a\u7a7a \uff1a " + cc.director.getScene().name);
          return null;
        }
        var root = rootScene.getChildByName("Canvas");
        if (!root) {
          true;
          cc.error("[LayerManager]", "\u5f53\u524d\u573a\u666f\u4e0a\u627e\u4e0d\u5230 Canvas \u8282\u70b9");
          return null;
        }
        return root;
      };
      LayerManager._instance = null;
      return LayerManager;
    }();
    exports.LayerManager = LayerManager;
    cc._RF.pop();
  }, {
    "../../Config/Macro": "Macro",
    "../../Defineds/Enums/Layer": "Layer"
  } ],
  Layer: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "3de85xnohVBjIPje2306e5t", "Layer");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.Layer = void 0;
    var Layer;
    (function(Layer) {
      var GameLayer;
      (function(GameLayer) {
        GameLayer[GameLayer["Content"] = 0] = "Content";
        GameLayer[GameLayer["Mask"] = 1] = "Mask";
        GameLayer[GameLayer["Tips"] = 2] = "Tips";
        GameLayer[GameLayer["Alert"] = 3] = "Alert";
        GameLayer[GameLayer["Loading"] = 4] = "Loading";
        GameLayer[GameLayer["UILoading"] = 5] = "UILoading";
      })(GameLayer = Layer.GameLayer || (Layer.GameLayer = {}));
      Layer.GameLayerNames = [ "LayerContent", "Mask", "Tips", "Alert", "Loading", "UILoading" ];
    })(Layer = exports.Layer || (exports.Layer = {}));
    cc._RF.pop();
  }, {} ],
  LobbyModule: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "8fe29dccNBBYYobjdEHXzUo", "LobbyModule");
    "use strict";
    var __extends = this && this.__extends || function() {
      var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function(d, b) {
          d.__proto__ = b;
        } || function(d, b) {
          for (var p in b) b.hasOwnProperty(p) && (d[p] = b[p]);
        };
        return extendStatics(d, b);
      };
      return function(d, b) {
        extendStatics(d, b);
        function __() {
          this.constructor = d;
        }
        d.prototype = null === b ? Object.create(b) : (__.prototype = b.prototype, new __());
      };
    }();
    var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : null === desc ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if ("object" === typeof Reflect && "function" === typeof Reflect.decorate) r = Reflect.decorate(decorators, target, key, desc); else for (var i = decorators.length - 1; i >= 0; i--) (d = decorators[i]) && (r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r);
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var ModuleComponent_1 = require("../../Framework/Component/ModuleComponent");
    var GameItemBinder_1 = require("../Binders/GameItemBinder");
    var ccclass = cc._decorator.ccclass;
    var LobbyModule = function(_super) {
      __extends(LobbyModule, _super);
      function LobbyModule() {
        return null !== _super && _super.apply(this, arguments) || this;
      }
      LobbyModule.getPrefabUrl = function() {
        return "prefabs/LobbyModule";
      };
      LobbyModule.prototype.show = function(option) {
        option.onShowed();
      };
      LobbyModule.prototype.hide = function(option) {
        option.onHided();
      };
      LobbyModule.prototype.onLoad = function() {
        this.initGameList();
      };
      LobbyModule.prototype.initGameList = function() {
        var subGameNode = this.find("gameItem");
        var gameList = this.find("gamelist");
        for (var i = 0; i < gamelist.length; i++) {
          var node = cc.instantiate(subGameNode);
          var binder = new GameItemBinder_1.GameItemBinder();
          node.name = gamelist[i].bundleName;
          gameList.addChild(node);
          binder.setNode(node, gamelist[i]);
          this.addBinder(binder);
        }
      };
      LobbyModule = __decorate([ ccclass ], LobbyModule);
      return LobbyModule;
    }(ModuleComponent_1.ModuleComponent);
    exports.default = LobbyModule;
    var gamelist = [ {
      name: "\u6e38\u620f1",
      bundleName: "gameOne",
      entryName: "GameOneGameEntry",
      manifestRoot: ""
    }, {
      name: "\u6e38\u620f2",
      bundleName: "gameTwo",
      entryName: "GameTwoGameEntry"
    }, {
      name: "\u5766\u514b\u5927\u6218",
      bundleName: "tankBattle",
      entryName: ""
    }, {
      name: "\u6269\u5c55Load\u63a5\u53e3\u793a\u4f8b",
      bundleName: "loadTest",
      entryName: ""
    }, {
      name: "\u7f51\u7edc\u793a\u4f8b",
      bundleName: "netTest",
      entryName: ""
    }, {
      name: "\u7784\u51c6\u7ebf",
      bundleName: "aimLine",
      entryName: ""
    }, {
      name: "\u8282\u70b9\u5bf9\u8c61\u6c60",
      bundleName: "nodePoolTest",
      entryName: ""
    }, {
      name: "Shader",
      bundleName: "shaders",
      entryName: ""
    }, {
      name: "\u4e09\u6d88",
      bundleName: "eliminate",
      entryName: ""
    } ];
    cc._RF.pop();
  }, {
    "../../Framework/Component/ModuleComponent": "ModuleComponent",
    "../Binders/GameItemBinder": "GameItemBinder"
  } ],
  LocalStorage: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "8f79b9Vk1lP7ZRWJgEVzFF2", "LocalStorage");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.LocalStorage = void 0;
    var BitEncrypt_1 = require("../../Extentions/BitEncrypt");
    var LocalStorage = function() {
      function LocalStorage() {
        this.key = "VuxiAKihQ0VR9WRe";
      }
      Object.defineProperty(LocalStorage, "Instance", {
        get: function() {
          return this._instance || (this._instance = new LocalStorage());
        },
        enumerable: false,
        configurable: true
      });
      LocalStorage.prototype.encrypt = function(obj) {
        return BitEncrypt_1.BitEncrypt.encode(JSON.stringify(obj), this.key);
      };
      LocalStorage.prototype.decryption = function(word) {
        return BitEncrypt_1.BitEncrypt.decode(word, this.key);
      };
      LocalStorage.prototype.getItem = function(key, encrypt, defaultValue) {
        void 0 === encrypt && (encrypt = true);
        void 0 === defaultValue && (defaultValue = null);
        var value = cc.sys.localStorage.getItem(key);
        if (!value) return defaultValue;
        if (!encrypt) {
          var result = JSON.parse(value);
          return result.type ? result.value : result;
        }
        try {
          var data = this.decryption(value);
          var result = JSON.parse(data);
          return result.type ? result.value : value;
        } catch (error) {
          return value;
        }
      };
      LocalStorage.prototype.setItem = function(key, value, encrypt) {
        void 0 === encrypt && (encrypt = true);
        var type = typeof value;
        if ("number" == type || "string" == type || "boolean" == type || "object" == type) {
          var saveObj = {
            type: type,
            value: value
          };
          var data = value;
          if (encrypt) try {
            var data_1 = this.encrypt(saveObj);
          } catch (error) {
            true;
            cc.error(error);
          }
          cc.sys.localStorage.setItem(key, data);
        } else {
          true;
          cc.error("\u5b58\u50a8\u6570\u636e\u7c7b\u578b\u4e0d\u652f\u6301 \u5f53\u524d\u7684\u5b58\u50a8\u7c7b\u578b: " + type);
        }
      };
      LocalStorage.prototype.removeItem = function(key) {
        cc.sys.localStorage.removeItem(key);
      };
      LocalStorage._instance = null;
      return LocalStorage;
    }();
    exports.LocalStorage = LocalStorage;
    cc._RF.pop();
  }, {
    "../../Extentions/BitEncrypt": "BitEncrypt"
  } ],
  LoginModule: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "4f9d1WndHNEeoFtka7UdbW0", "LoginModule");
    "use strict";
    var __extends = this && this.__extends || function() {
      var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function(d, b) {
          d.__proto__ = b;
        } || function(d, b) {
          for (var p in b) b.hasOwnProperty(p) && (d[p] = b[p]);
        };
        return extendStatics(d, b);
      };
      return function(d, b) {
        extendStatics(d, b);
        function __() {
          this.constructor = d;
        }
        d.prototype = null === b ? Object.create(b) : (__.prototype = b.prototype, new __());
      };
    }();
    var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : null === desc ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if ("object" === typeof Reflect && "function" === typeof Reflect.decorate) r = Reflect.decorate(decorators, target, key, desc); else for (var i = decorators.length - 1; i >= 0; i--) (d = decorators[i]) && (r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r);
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var ModuleComponent_1 = require("../../Framework/Component/ModuleComponent");
    var HotUpdateEnums_1 = require("../../Framework/Defineds/Enums/HotUpdateEnums");
    var HotUpdateManger_1 = require("../../Framework/Support/HotUpdate/HotUpdateManger");
    var ccclass = cc._decorator.ccclass;
    var LoginModule = function(_super) {
      __extends(LoginModule, _super);
      function LoginModule() {
        return null !== _super && _super.apply(this, arguments) || this;
      }
      LoginModule.getPrefabUrl = function() {
        return "prefabs/LoginModule";
      };
      LoginModule.prototype.show = function(option) {
        option.onShowed();
      };
      LoginModule.prototype.hide = function(option) {
        option.onHided();
      };
      LoginModule.prototype.onLoad = function() {
        var login = this.find("login");
        login.on(cc.Node.EventType.TOUCH_END, this._joinHall, this);
      };
      LoginModule.prototype._joinHall = function() {
        HotUpdateManger_1.HotUpdateManager.checkUpdate(this._test.bind(this), {
          name: "gameOne",
          isSkip: false,
          isMain: false,
          updateAddress: "http://192.168.3.151/hotupdate",
          manifestRoot: "manifest"
        });
      };
      LoginModule.prototype._test = function(code, state) {
        if (code == HotUpdateEnums_1.HotUpdateEnums.Code.ALREADY_UP_TO_DATE && state == HotUpdateEnums_1.HotUpdateEnums.State.UP_TO_DATE) manager.eventManager.dispatchEventWith("LOGIN_PANEL"); else if (code == HotUpdateEnums_1.HotUpdateEnums.Code.NEW_VERSION_FOUND && state == HotUpdateEnums_1.HotUpdateEnums.State.READY_TO_UPDATE) {
          var updater = manager.hotupdateManager.getUpdater("gameOne");
          updater && updater.runHotUpdate();
        }
        console.log("======================================>", code, state);
      };
      LoginModule.prototype._onClick = function() {};
      LoginModule = __decorate([ ccclass ], LoginModule);
      return LoginModule;
    }(ModuleComponent_1.ModuleComponent);
    exports.default = LoginModule;
    cc._RF.pop();
  }, {
    "../../Framework/Component/ModuleComponent": "ModuleComponent",
    "../../Framework/Defineds/Enums/HotUpdateEnums": "HotUpdateEnums",
    "../../Framework/Support/HotUpdate/HotUpdateManger": "HotUpdateManger"
  } ],
  Macro: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "a908dVk7xNE2I/XskNrtzUu", "Macro");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.Macro = void 0;
    var Macro;
    (function(Macro) {
      Macro.isSkipCheckUpdate = false;
      Macro.EnableLayerManager = true;
      Macro.MAX_INBACKGROUND_TIME = 60;
      Macro.MIN_INBACKGROUND_TIME = 5;
      Macro.BUNDLE_REMOTE = "__Remote__Caches__";
    })(Macro = exports.Macro || (exports.Macro = {}));
    cc._RF.pop();
  }, {} ],
  MainEvents: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "e35051hFgNBd6+WckG1RuDR", "MainEvents");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.MainEvents = void 0;
    var MainEvents = function() {
      function MainEvents() {}
      MainEvents.OPEN_BOOT_MODULE = "OPEN_BOOT_MODULE";
      MainEvents.OPEN_LOGIN_MODULE = "OPEN_LOGIN_MODULE";
      MainEvents.OPEN_LOBBY_MODULE = "OPEN_LOBBY_MODULE";
      return MainEvents;
    }();
    exports.MainEvents = MainEvents;
    cc._RF.pop();
  }, {} ],
  MainGameEntry: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "168b2f8+1dG1bOdQWhHiE/x", "MainGameEntry");
    "use strict";
    var __extends = this && this.__extends || function() {
      var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function(d, b) {
          d.__proto__ = b;
        } || function(d, b) {
          for (var p in b) b.hasOwnProperty(p) && (d[p] = b[p]);
        };
        return extendStatics(d, b);
      };
      return function(d, b) {
        extendStatics(d, b);
        function __() {
          this.constructor = d;
        }
        d.prototype = null === b ? Object.create(b) : (__.prototype = b.prototype, new __());
      };
    }();
    var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : null === desc ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if ("object" === typeof Reflect && "function" === typeof Reflect.decorate) r = Reflect.decorate(decorators, target, key, desc); else for (var i = decorators.length - 1; i >= 0; i--) (d = decorators[i]) && (r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r);
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.MainGameEntry = void 0;
    var Decorator_1 = require("../Framework/Decorator/Decorator");
    var GameEntry_1 = require("../Framework/Support/Entry/GameEntry");
    var MainModuleConfig_1 = require("./Configs/MainModuleConfig");
    var MainGameEntry = function(_super) {
      __extends(MainGameEntry, _super);
      function MainGameEntry() {
        return null !== _super && _super.apply(this, arguments) || this;
      }
      MainGameEntry.prototype.initEntry = function() {
        _super.prototype.initEntry.call(this);
        this.addModules(MainModuleConfig_1.MainModuleConfig);
      };
      MainGameEntry.prototype.onShowedByLogin = function() {
        this.closeModule(MainModuleConfig_1.MainModuleConfig.BootModule);
      };
      MainGameEntry.prototype.onShowedByLobby = function() {
        this.closeModule(MainModuleConfig_1.MainModuleConfig.LoginModule);
      };
      MainGameEntry = __decorate([ Decorator_1.ClassName(), Decorator_1.RegisterGameEntry() ], MainGameEntry);
      return MainGameEntry;
    }(GameEntry_1.GameEntry);
    exports.MainGameEntry = MainGameEntry;
    cc._RF.pop();
  }, {
    "../Framework/Decorator/Decorator": "Decorator",
    "../Framework/Support/Entry/GameEntry": "GameEntry",
    "./Configs/MainModuleConfig": "MainModuleConfig"
  } ],
  MainModuleConfig: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "93003hLZ+FG0bTpN1Z3srPZ", "MainModuleConfig");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.MainModuleConfig = void 0;
    var LobbyModule_1 = require("../Modules/LobbyModule");
    var BootModule_1 = require("../Modules/BootModule");
    var LoginModule_1 = require("../Modules/LoginModule");
    var Layer_1 = require("../../Framework/Defineds/Enums/Layer");
    var MainEvents_1 = require("../Events/MainEvents");
    exports.MainModuleConfig = {
      BootModule: {
        component: BootModule_1.default,
        event: MainEvents_1.MainEvents.OPEN_BOOT_MODULE,
        layer: Layer_1.Layer.GameLayer.Content,
        zIndex: 0,
        name: "BootModule",
        onShowedFuncName: null
      },
      LoginModule: {
        component: LoginModule_1.default,
        event: MainEvents_1.MainEvents.OPEN_LOGIN_MODULE,
        layer: Layer_1.Layer.GameLayer.Content,
        zIndex: 0,
        name: "LoginModule",
        onShowedFuncName: "onShowedByLogin"
      },
      LobbyModule: {
        component: LobbyModule_1.default,
        event: MainEvents_1.MainEvents.OPEN_LOBBY_MODULE,
        layer: Layer_1.Layer.GameLayer.Content,
        zIndex: 0,
        name: "LobbyModule",
        onShowedFuncName: "onShowedByLobby"
      }
    };
    cc._RF.pop();
  }, {
    "../../Framework/Defineds/Enums/Layer": "Layer",
    "../Events/MainEvents": "MainEvents",
    "../Modules/BootModule": "BootModule",
    "../Modules/LobbyModule": "LobbyModule",
    "../Modules/LoginModule": "LoginModule"
  } ],
  Main: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "c6c0eSX0+pN0JdPICmhP2D0", "Main");
    "use strict";
    var __extends = this && this.__extends || function() {
      var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function(d, b) {
          d.__proto__ = b;
        } || function(d, b) {
          for (var p in b) b.hasOwnProperty(p) && (d[p] = b[p]);
        };
        return extendStatics(d, b);
      };
      return function(d, b) {
        extendStatics(d, b);
        function __() {
          this.constructor = d;
        }
        d.prototype = null === b ? Object.create(b) : (__.prototype = b.prototype, new __());
      };
    }();
    var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : null === desc ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if ("object" === typeof Reflect && "function" === typeof Reflect.decorate) r = Reflect.decorate(decorators, target, key, desc); else for (var i = decorators.length - 1; i >= 0; i--) (d = decorators[i]) && (r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r);
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var ccclass = cc._decorator.ccclass;
    var MainEvents_1 = require("./Events/MainEvents");
    var Main = function(_super) {
      __extends(Main, _super);
      function Main() {
        return null !== _super && _super.apply(this, arguments) || this;
      }
      Main.prototype.onLoad = function() {
        manager.enteyManager.startGameEntry("MainGameEntry");
        manager.enteyManager.addExclude("MainGameEntry");
        manager.eventManager.dispatchEventWith(MainEvents_1.MainEvents.OPEN_BOOT_MODULE);
      };
      Main.prototype.update = function() {
        manager.serviceManager.update();
        manager.assetsManager.remote.update();
      };
      Main = __decorate([ ccclass ], Main);
      return Main;
    }(cc.Component);
    exports.default = Main;
    cc._RF.pop();
  }, {
    "./Events/MainEvents": "MainEvents"
  } ],
  ModuleBinder: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "2f748J3hBpLeLR6PzGlQM3Q", "ModuleBinder");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.ModuleBinder = void 0;
    var EventManager_1 = require("../Support/Event/EventManager");
    var ModuleBinder = function() {
      function ModuleBinder() {
        this.node = null;
        this.moduleNode = null;
        this._binders = [];
        this.initialize();
      }
      ModuleBinder.prototype.initialize = function() {};
      ModuleBinder.prototype.setNode = function(node) {
        var args = [];
        for (var _i = 1; _i < arguments.length; _i++) args[_i - 1] = arguments[_i];
        if (null != this.node) {
          this.removeEvents();
          this.clearViews();
        }
        this.node = node;
        this.initViews();
        this.addEvents();
      };
      ModuleBinder.prototype.initViews = function() {};
      ModuleBinder.prototype.addEvents = function() {};
      ModuleBinder.prototype.clearViews = function() {};
      ModuleBinder.prototype.removeEvents = function() {
        EventManager_1.EventManager.removeEvent(this);
      };
      ModuleBinder.prototype.update = function(data) {};
      ModuleBinder.prototype.destroy = function() {
        this.removeEvents();
        this.clearViews();
        this.destoryBinders();
        this.moduleNode = null;
        this.node = null;
      };
      ModuleBinder.prototype.addBinder = function(binder) {
        -1 == this._binders.indexOf(binder) && this._binders.push(binder);
      };
      ModuleBinder.prototype.destoryBinders = function() {
        while (this._binders.length > 0) this._binders.shift().destroy();
      };
      ModuleBinder.prototype.find = function(childPath) {
        var childs = childPath.split("/");
        var n = this.node;
        childs.forEach(function(s) {
          return n = n.getChildByName(s);
        });
        return n;
      };
      return ModuleBinder;
    }();
    exports.ModuleBinder = ModuleBinder;
    cc._RF.pop();
  }, {
    "../Support/Event/EventManager": "EventManager"
  } ],
  ModuleComponent: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "c9904wZJjxP/Ldx05kfAkGj", "ModuleComponent");
    "use strict";
    var __extends = this && this.__extends || function() {
      var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function(d, b) {
          d.__proto__ = b;
        } || function(d, b) {
          for (var p in b) b.hasOwnProperty(p) && (d[p] = b[p]);
        };
        return extendStatics(d, b);
      };
      return function(d, b) {
        extendStatics(d, b);
        function __() {
          this.constructor = d;
        }
        d.prototype = null === b ? Object.create(b) : (__.prototype = b.prototype, new __());
      };
    }();
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.ModuleComponent = void 0;
    var UIManager_1 = require("../Support/UIView/UIManager");
    var EventComponent_1 = require("./EventComponent");
    var ModuleBinder_1 = require("./ModuleBinder");
    var ModuleComponent = function(_super) {
      __extends(ModuleComponent, _super);
      function ModuleComponent() {
        var _this = null !== _super && _super.apply(this, arguments) || this;
        _this.maskClose = true;
        _this._destroyBinders = [];
        _this._bundle = null;
        _this._uiManager = UIManager_1.UIManager.Instance;
        return _this;
      }
      ModuleComponent.prototype.enabledMaskClose = function() {
        this.maskClose = true;
      };
      ModuleComponent.prototype.disableMaskClose = function() {
        this.maskClose = false;
      };
      Object.defineProperty(ModuleComponent.prototype, "isMaskClose", {
        get: function() {
          return this.maskClose;
        },
        enumerable: false,
        configurable: true
      });
      Object.defineProperty(ModuleComponent.prototype, "bundle", {
        get: function() {
          return this._bundle;
        },
        set: function(value) {
          this._bundle = value;
        },
        enumerable: false,
        configurable: true
      });
      Object.defineProperty(ModuleComponent.prototype, "openView", {
        get: function() {
          return this._uiManager.openView;
        },
        enumerable: false,
        configurable: true
      });
      ModuleComponent.getPrefabUrl = function() {
        return "";
      };
      ModuleComponent.prototype.addBinder = function(binder) {
        binder instanceof ModuleBinder_1.ModuleBinder && (binder["moduleNode"] = this.node);
        -1 == this._destroyBinders.indexOf(binder) && this._destroyBinders.push(binder);
      };
      ModuleComponent.prototype.destroyBinders = function() {
        while (this._destroyBinders.length > 0) this._destroyBinders.shift().destroy();
      };
      ModuleComponent.prototype.getComByPath = function(com, childPath) {
        var childs = childPath.split("/");
        var n = this.node;
        for (var i = 0; i < childs.length; i++) n = n.getChildByName(childs[i]);
        return n.getComponent(com);
      };
      ModuleComponent.prototype.find = function(childPath) {
        var childs = childPath.split("/");
        var n = this.node;
        childs.forEach(function(s) {
          return n = n.getChildByName(s);
        });
        return n;
      };
      ModuleComponent.prototype.onDestroy = function() {
        _super.prototype.onDestroy.call(this);
        this.destroyBinders();
      };
      ModuleComponent.prototype.close = function() {};
      return ModuleComponent;
    }(EventComponent_1.default);
    exports.ModuleComponent = ModuleComponent;
    cc._RF.pop();
  }, {
    "../Support/UIView/UIManager": "UIManager",
    "./EventComponent": "EventComponent",
    "./ModuleBinder": "ModuleBinder"
  } ],
  ModuleData: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "c0955kBZOdEeo+QZqksmO/t", "ModuleData");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.ModuleData = void 0;
    var ModuleStatusEnum_1 = require("../../Defineds/Enums/ModuleStatusEnum");
    var ModuleDynamicLoadData_1 = require("./ModuleDynamicLoadData");
    var ModuleData = function() {
      function ModuleData() {
        this.isLoaded = false;
        this.status = ModuleStatusEnum_1.ModuleStatusEnum.WAITTING_NONE;
        this.component = null;
        this.finishCb = [];
        this.getViewCb = [];
        this.isPreload = false;
        this.info = null;
        this.ViewData = {};
        this.loadData = new ModuleDynamicLoadData_1.ModuleDynamicLoadData();
        this.node = null;
      }
      ModuleData.prototype.doGet = function(view, className, msg) {
        for (var i = 0; i < this.getViewCb.length; i++) {
          var cb = this.getViewCb[i];
          if (cb) {
            cb(view);
            true;
            cc.warn("[ViewData]", "ViewData do get view : " + className + " msg : " + msg);
          }
        }
        this.getViewCb = [];
      };
      ModuleData.prototype.doFinish = function(view, className, msg) {
        for (var i = 0; i < this.finishCb.length; i++) {
          var cb = this.finishCb[i];
          if (cb) {
            cb(view);
            true;
            cc.warn("[ViewData]", "ViewData do finish view : " + className + " msg : " + msg);
          }
        }
        this.finishCb = [];
      };
      ModuleData.prototype.doCallback = function(view, className, msg) {
        this.doFinish(view, className, msg);
        this.doGet(view, className, msg);
      };
      return ModuleData;
    }();
    exports.ModuleData = ModuleData;
    cc._RF.pop();
  }, {
    "../../Defineds/Enums/ModuleStatusEnum": "ModuleStatusEnum",
    "./ModuleDynamicLoadData": "ModuleDynamicLoadData"
  } ],
  ModuleDynamicLoadData: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "bb4ceEtHI5JXp2PY2h/FITl", "ModuleDynamicLoadData");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.ModuleDynamicLoadData = void 0;
    var AssetsManager_1 = require("../Assets/AssetsManager");
    var CacheManager_1 = require("../Assets/CacheManager");
    var Const_1 = require("./Const");
    var UIManager_1 = require("./UIManager");
    var ModuleDynamicLoadData = function() {
      function ModuleDynamicLoadData(name) {
        void 0 === name && (name = null);
        this._logTag = "ModuleDynamicLoadData";
        this.local = new Map();
        this.remote = new Map();
        this.name = name;
      }
      ModuleDynamicLoadData.prototype.addLocal = function(info, className) {
        void 0 === className && (className = null);
        if (info && info.url) {
          this.name == Const_1.DYNAMIC_LOAD_GARBAGE && cc.error("[" + this._logTag + "]", "\u627e\u4e0d\u5230\u8d44\u6e90\u6301\u6709\u8005: " + info.url);
          true;
          UIManager_1.UIManager.Instance.checkView(info.url, className);
          if (!this.local.has(info.url)) {
            AssetsManager_1.AssetsManager.Instance.retainAsset(info);
            this.local.set(info.url, info);
          }
        }
      };
      ModuleDynamicLoadData.prototype.addRemote = function(info, className) {
        void 0 === className && (className = null);
        if (info && info.data && !this.remote.has(info.url)) {
          this.name == Const_1.DYNAMIC_LOAD_GARBAGE && cc.error("[" + this._logTag + "]", "\u627e\u4e0d\u5230\u8d44\u6e90\u6301\u6709\u8005 : " + info.url);
          true;
          UIManager_1.UIManager.Instance.checkView(info.url, className);
          CacheManager_1.CacheManager.Instance.remoteCaches.retainAsset(info);
          this.remote.set(info.url, info);
        }
      };
      ModuleDynamicLoadData.prototype.clear = function() {
        var _this = this;
        if (this.name == Const_1.DYNAMIC_LOAD_GARBAGE) {
          var isShow = this.local.size > 0 || this.remote.size > 0;
          isShow && cc.error("[" + this._logTag + "]", "\u5f53\u524d\u672a\u80fd\u91ca\u653e\u8d44\u6e90\u5982\u4e0b:");
          if (this.local && this.local.size > 0) {
            cc.error("[" + this._logTag + "]", "-----------local-----------");
            this.local && this.local.forEach(function(info) {
              cc.error("[" + _this._logTag + "]", info.url);
            });
          }
          if (this.remote && this.remote.size > 0) {
            cc.error("[" + this._logTag + "]", "-----------remote-----------");
            this.remote && this.remote.forEach(function(info, url) {
              cc.error("[" + _this._logTag + "]", info.url);
            });
          }
        } else {
          if (this.local) {
            this.local.forEach(function(info) {
              AssetsManager_1.AssetsManager.Instance.releaseAsset(info);
            });
            this.local.clear();
          }
          if (this.remote) {
            this.remote.forEach(function(info, url) {
              CacheManager_1.CacheManager.Instance.remoteCaches.releaseAsset(info);
            });
            this.remote.clear();
          }
        }
      };
      return ModuleDynamicLoadData;
    }();
    exports.ModuleDynamicLoadData = ModuleDynamicLoadData;
    cc._RF.pop();
  }, {
    "../Assets/AssetsManager": "AssetsManager",
    "../Assets/CacheManager": "CacheManager",
    "./Const": "Const",
    "./UIManager": "UIManager"
  } ],
  ModuleStatusEnum: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "4fa8av7G95K/LSd+VAP663T", "ModuleStatusEnum");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.ModuleStatusEnum = void 0;
    var ModuleStatusEnum;
    (function(ModuleStatusEnum) {
      ModuleStatusEnum[ModuleStatusEnum["WAITTING_CLOSE"] = 0] = "WAITTING_CLOSE";
      ModuleStatusEnum[ModuleStatusEnum["WATITING_HIDE"] = 1] = "WATITING_HIDE";
      ModuleStatusEnum[ModuleStatusEnum["WAITTING_NONE"] = 2] = "WAITTING_NONE";
    })(ModuleStatusEnum = exports.ModuleStatusEnum || (exports.ModuleStatusEnum = {}));
    cc._RF.pop();
  }, {} ],
  PopupControll: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "6a5247+GXBCIZ7ZWHMhBuOM", "PopupControll");
    "use strict";
    var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
      function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
          resolve(value);
        });
      }
      return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
          try {
            step(generator.next(value));
          } catch (e) {
            reject(e);
          }
        }
        function rejected(value) {
          try {
            step(generator["throw"](value));
          } catch (e) {
            reject(e);
          }
        }
        function step(result) {
          result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
      });
    };
    var __generator = this && this.__generator || function(thisArg, body) {
      var _ = {
        label: 0,
        sent: function() {
          if (1 & t[0]) throw t[1];
          return t[1];
        },
        trys: [],
        ops: []
      }, f, y, t, g;
      return g = {
        next: verb(0),
        throw: verb(1),
        return: verb(2)
      }, "function" === typeof Symbol && (g[Symbol.iterator] = function() {
        return this;
      }), g;
      function verb(n) {
        return function(v) {
          return step([ n, v ]);
        };
      }
      function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
          if (f = 1, y && (t = 2 & op[0] ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 
          0) : y.next) && !(t = t.call(y, op[1])).done) return t;
          (y = 0, t) && (op = [ 2 & op[0], t.value ]);
          switch (op[0]) {
           case 0:
           case 1:
            t = op;
            break;

           case 4:
            _.label++;
            return {
              value: op[1],
              done: false
            };

           case 5:
            _.label++;
            y = op[1];
            op = [ 0 ];
            continue;

           case 7:
            op = _.ops.pop();
            _.trys.pop();
            continue;

           default:
            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (6 === op[0] || 2 === op[0])) {
              _ = 0;
              continue;
            }
            if (3 === op[0] && (!t || op[1] > t[0] && op[1] < t[3])) {
              _.label = op[1];
              break;
            }
            if (6 === op[0] && _.label < t[1]) {
              _.label = t[1];
              t = op;
              break;
            }
            if (t && _.label < t[2]) {
              _.label = t[2];
              _.ops.push(op);
              break;
            }
            t[2] && _.ops.pop();
            _.trys.pop();
            continue;
          }
          op = body.call(thisArg, _);
        } catch (e) {
          op = [ 6, e ];
          y = 0;
        } finally {
          f = t = 0;
        }
        if (5 & op[0]) throw op[1];
        return {
          value: op[0] ? op[1] : void 0,
          done: true
        };
      }
    };
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.CHECK_OFF_MASK = exports.PopupControll = void 0;
    var Macro_1 = require("../../Framework/Config/Macro");
    var Layer_1 = require("../../Framework/Defineds/Enums/Layer");
    var Stack_1 = require("../../Libs/Stack");
    var Config_1 = require("../Config/Config");
    var PopupControll = function() {
      function PopupControll() {
        this._node = null;
        this._prefab = null;
        this._nodeStatck = new Stack_1.default();
      }
      Object.defineProperty(PopupControll, "Instance", {
        get: function() {
          return this._instance || (this._instance = new PopupControll());
        },
        enumerable: false,
        configurable: true
      });
      PopupControll.prototype.preloadPrefab = function() {
        if (!Macro_1.Macro.EnableLayerManager) return;
        this.loadPrefab();
      };
      PopupControll.prototype.loadPrefab = function() {
        return __awaiter(this, void 0, void 0, function() {
          var _this = this;
          return __generator(this, function(_a) {
            return [ 2, new Promise(function(resolve, reject) {
              if (_this._prefab) {
                resolve(true);
                return;
              }
              manager.assetsManager.load(RESOURCES, VIEW_PATH, cc.Prefab, function(finish, total, item) {}, function(data) {
                if (data && data.data && data.data instanceof cc.Prefab) {
                  manager.assetsManager.addPersistAsset(VIEW_PATH, data.data, RESOURCES);
                  _this._prefab = data.data;
                  resolve(true);
                } else resolve(false);
              });
            }) ];
          });
        });
      };
      PopupControll.prototype.showMask = function() {
        this._node || this._initView();
        if (true == this._node.active) return;
        cc.tween(this._node).set({
          active: true,
          opacity: 0
        }).to(.2, {
          opacity: Config_1.Config.defaultOpacity
        }).start();
      };
      PopupControll.prototype.hideMask = function() {
        var _this = this;
        if (!this._node) return;
        if (false == this._node.active) return;
        cc.tween(this._node).to(.2, {
          opacity: 0
        }).call(function() {
          _this._node.active = false;
        }).start();
      };
      PopupControll.prototype._initView = function() {
        this._node = cc.instantiate(this._prefab);
        manager.uiManager.addChild(this._node, Layer_1.Layer.GameLayer.Mask, 0);
        this._node.active = false;
        var btn = cc.find("single_color", this._node);
        btn.color = cc.Color.fromHEX(btn.color, Config_1.Config.defaultColor);
        btn.on("click", this._onClose, this, true);
        manager.eventManager.addEvent(this, exports.CHECK_OFF_MASK, this.isOffMask);
      };
      PopupControll.prototype._onClose = function() {
        this.close();
      };
      PopupControll.prototype.popup = function(ui) {
        if (!Config_1.Config.EnableMask) return;
        this.showMask();
        this._nodeStatck.push(ui);
      };
      PopupControll.prototype.show = function() {
        this.showMask();
      };
      PopupControll.prototype.close = function(uiNode) {
        if (!Config_1.Config.EnableMask) return;
        if (this._nodeStatck.isEmpty() && true == this._node.active && null == uiNode) return this.isOffMask();
        if (uiNode) {
          var idx = this._nodeStatck.indexOf(uiNode);
          if (-1 != idx) {
            this._nodeStatck.del(idx);
            this.isOffMask();
          }
        } else {
          uiNode = this._nodeStatck.last();
          if (uiNode && uiNode.isMaskClose) {
            manager.uiManager.close(cc.js.getClassName(uiNode));
            this._nodeStatck.pop();
            this.isOffMask();
          }
        }
      };
      PopupControll.prototype.isOffMask = function() {
        this._nodeStatck.isEmpty() && this.hideMask();
      };
      PopupControll._instance = null;
      return PopupControll;
    }();
    exports.PopupControll = PopupControll;
    var RESOURCES = "resources";
    var VIEW_PATH = "common/prefabs/MaskView";
    exports.CHECK_OFF_MASK = "CHECK_OFF_MASK";
    cc._RF.pop();
  }, {
    "../../Framework/Config/Macro": "Macro",
    "../../Framework/Defineds/Enums/Layer": "Layer",
    "../../Libs/Stack": "Stack",
    "../Config/Config": "Config"
  } ],
  PopupModule: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "1789eMZ0yJPlIXRsqq/w8cv", "PopupModule");
    "use strict";
    var __extends = this && this.__extends || function() {
      var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function(d, b) {
          d.__proto__ = b;
        } || function(d, b) {
          for (var p in b) b.hasOwnProperty(p) && (d[p] = b[p]);
        };
        return extendStatics(d, b);
      };
      return function(d, b) {
        extendStatics(d, b);
        function __() {
          this.constructor = d;
        }
        d.prototype = null === b ? Object.create(b) : (__.prototype = b.prototype, new __());
      };
    }();
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var ModuleComponent_1 = require("../../Framework/Component/ModuleComponent");
    var PopupModule = function(_super) {
      __extends(PopupModule, _super);
      function PopupModule() {
        var _this = null !== _super && _super.apply(this, arguments) || this;
        _this._data = null;
        return _this;
      }
      Object.defineProperty(PopupModule.prototype, "data", {
        get: function() {
          return this._data;
        },
        enumerable: false,
        configurable: true
      });
      PopupModule.prototype.show = function(option) {
        this._data = option.data;
        manager.popupControll.popup(this);
        option.onShowed();
      };
      PopupModule.prototype.hide = function(option) {
        option.onHided();
      };
      return PopupModule;
    }(ModuleComponent_1.ModuleComponent);
    exports.default = PopupModule;
    cc._RF.pop();
  }, {
    "../../Framework/Component/ModuleComponent": "ModuleComponent"
  } ],
  ProcessLoading: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "027c5FgJ3FKNppLSSq2WPYm", "ProcessLoading");
    "use strict";
    var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
      function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
          resolve(value);
        });
      }
      return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
          try {
            step(generator.next(value));
          } catch (e) {
            reject(e);
          }
        }
        function rejected(value) {
          try {
            step(generator["throw"](value));
          } catch (e) {
            reject(e);
          }
        }
        function step(result) {
          result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
      });
    };
    var __generator = this && this.__generator || function(thisArg, body) {
      var _ = {
        label: 0,
        sent: function() {
          if (1 & t[0]) throw t[1];
          return t[1];
        },
        trys: [],
        ops: []
      }, f, y, t, g;
      return g = {
        next: verb(0),
        throw: verb(1),
        return: verb(2)
      }, "function" === typeof Symbol && (g[Symbol.iterator] = function() {
        return this;
      }), g;
      function verb(n) {
        return function(v) {
          return step([ n, v ]);
        };
      }
      function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
          if (f = 1, y && (t = 2 & op[0] ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 
          0) : y.next) && !(t = t.call(y, op[1])).done) return t;
          (y = 0, t) && (op = [ 2 & op[0], t.value ]);
          switch (op[0]) {
           case 0:
           case 1:
            t = op;
            break;

           case 4:
            _.label++;
            return {
              value: op[1],
              done: false
            };

           case 5:
            _.label++;
            y = op[1];
            op = [ 0 ];
            continue;

           case 7:
            op = _.ops.pop();
            _.trys.pop();
            continue;

           default:
            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (6 === op[0] || 2 === op[0])) {
              _ = 0;
              continue;
            }
            if (3 === op[0] && (!t || op[1] > t[0] && op[1] < t[3])) {
              _.label = op[1];
              break;
            }
            if (6 === op[0] && _.label < t[1]) {
              _.label = t[1];
              t = op;
              break;
            }
            if (t && _.label < t[2]) {
              _.label = t[2];
              _.ops.push(op);
              break;
            }
            t[2] && _.ops.pop();
            _.trys.pop();
            continue;
          }
          op = body.call(thisArg, _);
        } catch (e) {
          op = [ 6, e ];
          y = 0;
        } finally {
          f = t = 0;
        }
        if (5 & op[0]) throw op[1];
        return {
          value: op[0] ? op[1] : void 0,
          done: true
        };
      }
    };
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.ProcessLoading = void 0;
    var Layer_1 = require("../../Framework/Defineds/Enums/Layer");
    var ProcessLoading = function() {
      function ProcessLoading() {
        this._node = null;
        this._loop = null;
        this._text = null;
        this._prefab = null;
      }
      Object.defineProperty(ProcessLoading, "Instance", {
        get: function() {
          return this._instance || (this._instance = new ProcessLoading());
        },
        enumerable: false,
        configurable: true
      });
      ProcessLoading.prototype.preloadPrefab = function() {
        this.loadPrefab();
      };
      ProcessLoading.prototype.loadPrefab = function() {
        return __awaiter(this, void 0, void 0, function() {
          var _this = this;
          return __generator(this, function(_a) {
            return [ 2, new Promise(function(resolve, reject) {
              if (_this._prefab) {
                resolve(true);
                return;
              }
              manager.assetsManager.load(RESOURCES, VIEW_PATH, cc.Prefab, function(finish, total, item) {}, function(data) {
                if (data && data.data && data.data instanceof cc.Prefab) {
                  manager.assetsManager.addPersistAsset(VIEW_PATH, data.data, RESOURCES);
                  _this._prefab = data.data;
                  resolve(true);
                } else resolve(false);
              });
            }) ];
          });
        });
      };
      ProcessLoading.prototype._initView = function() {
        this._node = cc.instantiate(this._prefab);
        manager.uiManager.addChild(this._node, Layer_1.Layer.GameLayer.UILoading, 0);
        this._node.active = false;
        this._loop = cc.find("content/icon", this._node);
        this._text = cc.find("content/text", this._node).getComponent(cc.Label);
      };
      ProcessLoading.prototype.show = function(info) {
        this._node || this._initView();
        this._text.string = info;
        if (true == this._node.active) return;
        this._node.active = true;
        cc.Tween.stopAllByTarget(this._loop);
        var loop = cc.tween().to(.5, {
          angle: -360
        });
        cc.tween(this._loop).repeatForever(loop).start();
      };
      ProcessLoading.prototype.hide = function() {
        if (false == this._node.active) return;
        this._node.active = false;
        this._text.string = "";
        cc.Tween.stopAllByTarget(this._loop);
      };
      ProcessLoading._instance = null;
      return ProcessLoading;
    }();
    exports.ProcessLoading = ProcessLoading;
    var RESOURCES = "resources";
    var VIEW_PATH = "common/prefabs/ProcessLoading";
    cc._RF.pop();
  }, {
    "../../Framework/Defineds/Enums/Layer": "Layer"
  } ],
  Process: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "d5b98Ytu4hLiLSsLWxU2ifv", "Process");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.Process = void 0;
    var Process = function() {
      function Process() {
        this.Codec = null;
        this._listeners = {};
        this._masseageQueue = new Array();
        this._isDoingMessage = false;
        this.isPause = false;
      }
      Process.prototype.pauseMessageQueue = function() {
        this.isPause = true;
      };
      Process.prototype.resumeMessageQueue = function() {
        this.isPause = false;
      };
      Process.prototype.handMessage = function() {
        var _this = this;
        if (this.isPause) return;
        if (this._isDoingMessage) return;
        if (0 == this._masseageQueue.length) return;
        var datas = this._masseageQueue.shift();
        if (void 0 == datas) return;
        if (0 == datas.length) return;
        this._isDoingMessage = true;
        var handleTime = 0;
        true;
        cc.log("---handMessage---");
        for (var i = 0; i < datas.length; i++) {
          var data = datas[i];
          if (data.func instanceof Function) try {
            var tempTime = data.func.call(data.target, data.data);
            "number" == typeof tempTime && (handleTime = Math.max(handleTime, tempTime));
          } catch (error) {
            cc.error(error);
          }
        }
        0 == handleTime ? this._isDoingMessage = false : manager.layerManager.getCanvasComponent().scheduleOnce(function() {
          _this._isDoingMessage = false;
        }, handleTime);
      };
      Process.prototype.onMessage = function(code) {
        cc.log("recv data main cmd : " + code.getCmdID());
        var key = code.getCmdID();
        if (!this._listeners[key]) {
          cc.warn("no find listener data main cmd : " + code.getCmdID());
          return;
        }
        if (this._listeners[key].length <= 0) return;
        this.addMessageQueue(key, code, true);
      };
      Process.prototype.reset = function() {
        this._isDoingMessage = false;
        this._listeners = {};
        this._masseageQueue = [];
        this.resumeMessageQueue();
      };
      Process.prototype.close = function() {
        this._masseageQueue = [];
        this._isDoingMessage = false;
      };
      Process.prototype.addListener = function(eventName, handleType, handleFunc, isQueue, target) {
        var key = eventName;
        if (this._listeners[key]) {
          var hasSame = false;
          for (var i = 0; i < this._listeners[key].length; i++) if (this._listeners[key][i].target === target) {
            hasSame = true;
            break;
          }
          if (hasSame) return;
          this._listeners[key].push({
            eventName: eventName,
            func: handleFunc,
            type: handleType,
            isQueue: isQueue,
            target: target
          });
        } else {
          this._listeners[key] = [];
          this._listeners[key].push({
            eventName: eventName,
            func: handleFunc,
            type: handleType,
            isQueue: isQueue,
            target: target
          });
        }
      };
      Process.prototype.removeListeners = function(target, eventName) {
        if (eventName) {
          var self_1 = this;
          Object.keys(this._listeners).forEach(function(value) {
            var datas = self_1._listeners[value];
            var i = datas.length;
            while (i--) datas[i].target == target && datas[i].eventName == eventName && datas.splice(i, 1);
            0 == datas.length && delete self_1._listeners[value];
          });
          var i = this._masseageQueue.length;
          while (i--) {
            var datas = this._masseageQueue[i];
            var j = datas.length;
            while (j--) datas[j].target == target && datas[i].eventName == eventName && datas.splice(j, 1);
            0 == datas.length && this._masseageQueue.splice(i, 1);
          }
        } else {
          var self_2 = this;
          Object.keys(this._listeners).forEach(function(value, index, arr) {
            var datas = self_2._listeners[value];
            var i = datas.length;
            while (i--) datas[i].target == target && datas.splice(i, 1);
            0 == datas.length && delete self_2._listeners[value];
          });
          var i = this._masseageQueue.length;
          while (i--) {
            var datas = this._masseageQueue[i];
            var j = datas.length;
            while (j--) datas[j].target == target && datas.splice(j, 1);
            0 == datas.length && this._masseageQueue.splice(i, 1);
          }
        }
      };
      Process.prototype.decode = function(o, header) {
        var obj = null;
        if (o.type) {
          obj = new o.type();
          obj.decode(header.getData());
        } else obj = header.getData();
        return obj;
      };
      Process.prototype.addMessageQueue = function(key, data, encode) {
        if (this._listeners[key].length <= 0) return;
        var listenerDatas = this._listeners[key];
        var queueDatas = [];
        for (var i = 0; i < listenerDatas.length; i++) {
          var obj = data;
          encode && (obj = this.decode(listenerDatas[i], data));
          if (listenerDatas[i].isQueue) queueDatas.push(this.copyListenerData(listenerDatas[i], obj)); else try {
            listenerDatas[i].func && listenerDatas[i].func.call(listenerDatas[i].target, obj);
          } catch (err) {
            cc.error(err);
          }
        }
        queueDatas.length > 0 && this._masseageQueue.push(queueDatas);
      };
      Process.prototype.copyListenerData = function(input, data) {
        return {
          type: input.type,
          func: input.func,
          isQueue: input.isQueue,
          data: data,
          target: input.target,
          eventName: input.eventName
        };
      };
      return Process;
    }();
    exports.Process = Process;
    cc._RF.pop();
  }, {} ],
  Queue: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "22f67qiK19EhJT5rfSMPq1g", "Queue");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var Queue = function() {
      function Queue() {
        this._array = new Array();
      }
      Queue.prototype.push = function(element) {
        if (null == element) return false;
        this._array.push(element);
        return true;
      };
      Queue.prototype.pop = function() {
        return this._array.shift();
      };
      Queue.prototype.first = function() {
        return this.isEmpty() ? null : this._array[0];
      };
      Queue.prototype.last = function() {
        return this.isEmpty() ? null : this._array[this.size() - 1];
      };
      Queue.prototype.size = function() {
        return this._array.length;
      };
      Queue.prototype.isEmpty = function() {
        return 0 === this.size();
      };
      Queue.prototype.clear = function() {
        delete this._array;
      };
      return Queue;
    }();
    exports.default = Queue;
    cc._RF.pop();
  }, {} ],
  RemoteCaches: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "a39edVLaS9MaogGGuhuIH62", "RemoteCaches");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.RemoteCaches = void 0;
    var IResource_1 = require("../../Defineds/Interfaces/IResource");
    var CacheInfo = function() {
      function CacheInfo() {
        this.refCount = 0;
        this.url = "";
        this.retain = false;
      }
      return CacheInfo;
    }();
    var RemoteCaches = function() {
      function RemoteCaches() {
        this._caches = new Map();
        this._spriteFrameCaches = new Map();
        this._resMap = new Map();
      }
      RemoteCaches.prototype.get = function(url) {
        if (this._caches.has(url)) return this._caches.get(url);
        return null;
      };
      RemoteCaches.prototype.getBundleName = function(bundle) {
        return "string" == typeof bundle ? bundle : bundle ? bundle.name : null;
      };
      RemoteCaches.prototype.getSpriteFrame = function(url) {
        if (this._spriteFrameCaches.has(url)) {
          var cache = this._spriteFrameCaches.get(url);
          var texture2D = this.get(url);
          if (texture2D) return cache;
          this.remove(url);
          return null;
        }
        return null;
      };
      RemoteCaches.prototype.setSpriteFrame = function(url, data) {
        if (data && data instanceof cc.Texture2D) {
          var spriteFrame = this.getSpriteFrame(url);
          if (spriteFrame) return spriteFrame.data;
          var cache = new IResource_1.IResource.ResourceCacheData();
          cache.data = new cc.SpriteFrame(data);
          cache.isLoaded = true;
          cache.info.url = url;
          this._spriteFrameCaches.set(url, cache);
          return cache.data;
        }
        return null;
      };
      RemoteCaches.prototype.set = function(url, data) {
        data.info.url = url;
        this._caches.set(url, data);
      };
      RemoteCaches.prototype._getCacheInfo = function(info, isNoFoundCreate) {
        void 0 === isNoFoundCreate && (isNoFoundCreate = true);
        if (info && info.url && info.url.length > 0) {
          if (!this._resMap.has(info.url)) {
            if (!isNoFoundCreate) return null;
            var cache = new CacheInfo();
            cache.url = info.url;
            this._resMap.set(info.url, cache);
          }
          return this._resMap.get(info.url);
        }
        return null;
      };
      RemoteCaches.prototype.retainAsset = function(info) {
        if (info && info.data) {
          var cache = this._getCacheInfo(info);
          if (cache) {
            if (cache.retain) {
              if (!info.retain) {
                true;
                cc.warn("[RemoteCaches]", "\u8d44\u6e90 : " + info.url + " \u5df2\u7ecf\u88ab\u8bbe\u7f6e\u6210\u5e38\u9a7b\u8d44\u6e90\uff0c\u4e0d\u80fd\u6539\u53d8\u5176\u5c5e\u6027");
              }
            } else cache.retain = info.retain;
            info.data.addRef();
            cache.refCount++;
            cache.retain && (cache.refCount = 999999);
          }
        }
      };
      RemoteCaches.prototype.releaseAsset = function(info) {
        if (info && info.data) {
          var cache = this._getCacheInfo(info, false);
          if (cache) {
            if (cache.retain) return;
            cache.refCount--;
            cache.refCount <= 0 && this.remove(cache.url);
          }
        }
      };
      RemoteCaches.prototype.remove = function(url) {
        this._resMap.delete(url);
        if (this._spriteFrameCaches.has(url)) {
          this._spriteFrameCaches.get(url).data.decRef();
          this._spriteFrameCaches.delete(url);
          true;
          cc.log("[RemoteCaches]", "remove remote sprite frames resource url : " + url);
        }
        var cache = this._caches.has(url) ? this._caches.get(url) : null;
        if (cache && cache.data instanceof sp.SkeletonData) {
          this.remove(cache.info.url + ".atlas");
          this.remove(cache.info.url + ".png");
          this.remove(cache.info.url + ".json");
        }
        if (cache && cache.data instanceof cc.Asset) {
          true;
          cc.log("[RemoteCaches]", "\u91ca\u653e\u52a0\u8f7d\u7684\u672c\u5730\u8fdc\u7a0b\u8d44\u6e90:" + cache.info.url);
          cache.data.decRef();
          cc.assetManager.releaseAsset(cache.data);
        }
        true;
        cc.log("[RemoteCaches]", "remove remote cache url : " + url);
        return this._caches.delete(url);
      };
      RemoteCaches.prototype.showCaches = function() {
        cc.log("---- [RemoteCaches] showCaches ----");
        var content = [];
        var invalidContent = [];
        this._spriteFrameCaches.forEach(function(data, key, source) {
          var itemContent = {
            url: data.info.url,
            isLoaded: data.isLoaded,
            isValid: cc.isValid(data.data),
            assetType: cc.js.getClassName(data.info.type),
            data: data.data ? cc.js.getClassName(data.data) : null,
            status: data.status
          };
          var item = {
            url: key,
            data: itemContent
          };
          data.isLoaded && (data.data && !cc.isValid(data.data) || !data.data) ? invalidContent.push(item) : content.push(item);
        });
        if (content.length > 0) {
          cc.log("----------------Current valid spriteFrame Caches------------------");
          cc.log(JSON.stringify(content));
        }
        if (invalidContent.length > 0) {
          cc.log("----------------Current invalid spriteFrame Caches------------------");
          cc.log(JSON.stringify(invalidContent));
        }
        content = [];
        invalidContent = [];
        this._caches.forEach(function(data, key, source) {
          var itemContent = {
            url: data.info.url,
            isLoaded: data.isLoaded,
            isValid: cc.isValid(data.data),
            assetType: cc.js.getClassName(data.info.type),
            data: data.data ? cc.js.getClassName(data.data) : null,
            status: data.status
          };
          var item = {
            url: key,
            data: itemContent
          };
          data.isLoaded && data.data && !cc.isValid(data.data) ? invalidContent.push(item) : content.push(item);
        });
        if (content.length > 0) {
          cc.log("----------------Current valid Caches------------------");
          cc.log(JSON.stringify(content));
        }
        if (invalidContent.length > 0) {
          cc.log("----------------Current invalid Caches------------------");
          cc.log(JSON.stringify(invalidContent));
        }
        if (this._resMap.size > 0) {
          cc.log("----------------Current resource reference Caches------------------");
          content = [];
          this._resMap.forEach(function(value, key) {
            var item = {
              url: key,
              data: {
                refCount: value.refCount,
                url: value.url,
                retain: value.retain
              }
            };
            content.push(item);
          });
          cc.log(JSON.stringify(content));
        }
      };
      return RemoteCaches;
    }();
    exports.RemoteCaches = RemoteCaches;
    cc._RF.pop();
  }, {
    "../../Defineds/Interfaces/IResource": "IResource"
  } ],
  RemoteLoader: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "1e7167zhwBNhZAzP5W+cNh7", "RemoteLoader");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.RemoteLoader = void 0;
    var Macro_1 = require("../../Config/Macro");
    var ResourceType_1 = require("../../Defineds/Enums/ResourceType");
    var IResource_1 = require("../../Defineds/Interfaces/IResource");
    var CacheManager_1 = require("./CacheManager");
    var RemoteLoader = function() {
      function RemoteLoader() {
        this._logTag = "[RemoteLoader] ";
      }
      Object.defineProperty(RemoteLoader, "Instance", {
        get: function() {
          return this._instance || (this._instance = new RemoteLoader());
        },
        enumerable: false,
        configurable: true
      });
      RemoteLoader.prototype.loadImage = function(url, isNeedCache) {
        var _this = this;
        var me = this;
        return new Promise(function(resolve) {
          if (null == url || void 0 == url || url.length <= 0) {
            resolve(null);
            return;
          }
          if (isNeedCache) {
            var spCache = CacheManager_1.CacheManager.Instance.remoteCaches.getSpriteFrame(url);
            if (spCache && spCache.data) {
              true;
              cc.log(_this._logTag, "\u4ece\u7f13\u5b58\u7cbe\u7075\u5e27\u4e2d\u83b7\u53d6:" + url);
              resolve(spCache.data);
              return;
            }
            true;
            cc.log(_this._logTag, "\u9519\u8bef\u8d44\u6e90\uff0c\u5220\u9664\u7f13\u5b58\u4fe1\u606f\uff0c\u91cd\u65b0\u52a0\u8f7d:" + url);
            CacheManager_1.CacheManager.Instance.remoteCaches.remove(url);
          } else {
            true;
            cc.log(_this._logTag, "\u4e0d\u9700\u8981\u7f13\u5b58\u4fe1\u606f\uff0c\u5220\u9664\u7f13\u5b58\uff0c\u91cd\u65b0\u52a0\u8f7d" + url);
            CacheManager_1.CacheManager.Instance.remoteCaches.remove(url);
          }
          me._loadRemoteRes(url, cc.Texture2D, isNeedCache).then(function(data) {
            var cache = CacheManager_1.CacheManager.Instance.remoteCaches.get(url);
            if (data && cache) {
              true;
              cc.log(_this._logTag + "\u52a0\u8f7d\u56fe\u7247\u5b8c\u6210" + url);
              cache.data = data;
              cache.data.name = url;
              var spriteFrame = CacheManager_1.CacheManager.Instance.remoteCaches.setSpriteFrame(url, cache.data);
              resolve(spriteFrame);
            } else {
              true;
              cc.warn(_this._logTag + "\u52a0\u8f7d\u56fe\u7247\u9519\u8bef" + url);
              resolve(null);
            }
          });
        });
      };
      RemoteLoader.prototype.loadSkeleton = function(path, name, isNeedCache) {
        var me = this;
        return new Promise(function(resolve) {
          if (path && name) {
            var url_1 = path + "/" + name;
            var spineAtlas_1 = path + "/" + name + ".atlas";
            var spinePng = path + "/" + name + ".png";
            var spineJson_1 = path + "/" + name + ".json";
            var cache_1 = CacheManager_1.CacheManager.Instance.remoteCaches.get(url_1);
            if (cache_1) cache_1.isLoaded ? resolve(cache_1.data) : cache_1.finishCb.push(resolve); else {
              cache_1 = new IResource_1.IResource.ResourceCacheData();
              cache_1.info.resourceType = ResourceType_1.ResourceType.Remote;
              cache_1.info.type = sp.SkeletonData;
              cache_1.info.bundle = Macro_1.Macro.BUNDLE_REMOTE;
              CacheManager_1.CacheManager.Instance.remoteCaches.set(url_1, cache_1);
              me._loadRemoteRes(spinePng, cc.Texture2D, isNeedCache).then(function(texture) {
                if (texture) me._loadRemoteRes(spineJson_1, cc.JsonAsset, isNeedCache).then(function(json) {
                  if (json) me._loadRemoteRes(spineAtlas_1, cc.JsonAsset, isNeedCache).then(function(atlas) {
                    if (atlas) {
                      var asset = new sp.SkeletonData();
                      asset.skeletonJson = json.json;
                      asset.atlasText = atlas.text;
                      asset.textures = [ texture ];
                      var pngName = name + ".png";
                      asset["textureNames"] = [ pngName ];
                      cache_1.info.url = url_1;
                      asset.name = url_1;
                      cache_1.data = asset;
                      cache_1.isLoaded = true;
                      resolve(cache_1.data);
                      cache_1.doFinish(cache_1.data);
                    } else {
                      resolve(null);
                      cache_1.doFinish(null);
                      CacheManager_1.CacheManager.Instance.remoteCaches.remove(url_1);
                    }
                  }); else {
                    resolve(null);
                    cache_1.doFinish(null);
                    CacheManager_1.CacheManager.Instance.remoteCaches.remove(url_1);
                  }
                }); else {
                  resolve(null);
                  cache_1.doFinish(null);
                  CacheManager_1.CacheManager.Instance.remoteCaches.remove(url_1);
                }
              });
            }
          } else resolve(null);
        });
      };
      RemoteLoader.prototype._loadRemoteRes = function(url, type, isNeedCache) {
        var _this = this;
        return new Promise(function(resolve) {
          var cache = CacheManager_1.CacheManager.Instance.remoteCaches.get(url);
          if (cache) cache.isLoaded ? resolve(cache.data) : cache.finishCb.push(resolve); else {
            cache = new IResource_1.IResource.ResourceCacheData();
            cache.info.resourceType = ResourceType_1.ResourceType.Remote;
            cache.info.type = type;
            CacheManager_1.CacheManager.Instance.remoteCaches.set(url, cache);
            cc.assetManager.loadRemote(url, function(error, data) {
              cache.isLoaded = true;
              if (data) {
                cache.data = data;
                cache.data.addRef();
                true;
                cc.log(_this._logTag + "\u52a0\u8f7d\u8fdc\u7a0b\u8d44\u6e90\u5b8c\u6210:" + url);
              } else {
                true;
                cc.warn(_this._logTag + "\u52a0\u8f7d\u672c\u5730\u8d44\u6e90\u5f02\u5e38:" + url);
              }
              cache.doFinish(data);
              resolve(cache.data);
            });
          }
        });
      };
      RemoteLoader.prototype.update = function() {};
      RemoteLoader._instance = null;
      return RemoteLoader;
    }();
    exports.RemoteLoader = RemoteLoader;
    cc._RF.pop();
  }, {
    "../../Config/Macro": "Macro",
    "../../Defineds/Enums/ResourceType": "ResourceType",
    "../../Defineds/Interfaces/IResource": "IResource",
    "./CacheManager": "CacheManager"
  } ],
  ResourceCacheStatus: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "3c7a8XK3YRPMpuOBXfbegOP", "ResourceCacheStatus");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.ResourceCacheStatus = void 0;
    var ResourceCacheStatus;
    (function(ResourceCacheStatus) {
      ResourceCacheStatus[ResourceCacheStatus["NONE"] = 0] = "NONE";
      ResourceCacheStatus[ResourceCacheStatus["WAITTING_FOR_RELEASE"] = 1] = "WAITTING_FOR_RELEASE";
    })(ResourceCacheStatus = exports.ResourceCacheStatus || (exports.ResourceCacheStatus = {}));
    cc._RF.pop();
  }, {} ],
  ResourceCache: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "4825128+ZhBC74YHVPDEscN", "ResourceCache");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.ResourceCache = void 0;
    var ResourceCache = function() {
      function ResourceCache(name) {
        this.name = name;
        this._caches = new Map();
      }
      ResourceCache.prototype.print = function() {
        var content = [];
        var invalidContent = [];
        this._caches.forEach(function(data, key, source) {
          var itemContent = {
            url: data.info.url,
            isLoaded: data.isLoaded,
            isValid: cc.isValid(data.data),
            assetType: cc.js.getClassName(data.info.type),
            data: data.data ? cc.js.getClassName(data.data) : null,
            status: data.status
          };
          var item = {
            url: key,
            data: itemContent
          };
          data.isLoaded && data.data && !cc.isValid(data.data) ? invalidContent.push(item) : content.push(item);
        });
        if (content.length > 0) {
          cc.log("[ResourceCache]", "----------- Current valid caches -----------");
          cc.log("[ResourceCache]", JSON.stringify(content));
        }
        if (invalidContent.length > 0) {
          cc.log("[ResourceCache]", "----------- Current invalid caches -----------");
          cc.log("[ResourceCache]", JSON.stringify(invalidContent));
        }
      };
      ResourceCache.prototype.get = function(path, isCheck) {
        if (this._caches.has(path)) {
          var cache = this._caches.get(path);
          if (isCheck && cache.isInvalid) {
            cc.warn("[ResourceCache]", "\u8d44\u6e90\u52a0\u8f7d\u5b8c\u6210\uff0c\u4f46\u5df2\u7ecf\u88ab\u91ca\u653e , \u91cd\u65b0\u52a0\u8f7d\u8d44\u6e90 : " + path);
            this.remove(path);
            return null;
          }
          return this._caches.get(path);
        }
        return null;
      };
      ResourceCache.prototype.set = function(path, data) {
        this._caches.set(path, data);
      };
      ResourceCache.prototype.remove = function(path) {
        return this._caches.delete(path);
      };
      ResourceCache.prototype.removeUnuseCaches = function() {
        var _this = this;
        this._caches.forEach(function(value, key, origin) {
          if (Array.isArray(value.data)) {
            var isAllDelete = true;
            for (var i = 0; i < value.data.length; i++) value.data[i] && 0 != value.data[i].refCount && (isAllDelete = false);
            if (isAllDelete) {
              _this._caches.delete(key);
              true;
              cc.log("[ResourceCache]", "\u5220\u9664\u4e0d\u4f7f\u7528\u7684\u8d44\u6e90\u76ee\u5f55 bundle : " + _this.name + " dir : " + key);
            }
          } else if (value.data && 0 == value.data.refCount) {
            _this._caches.delete(key);
            true;
            cc.log("[ResourceCache]", "\u5220\u9664\u4e0d\u4f7f\u7528\u7684\u8d44\u6e90 bundle : " + _this.name + " url : " + key);
          }
        });
      };
      Object.defineProperty(ResourceCache.prototype, "size", {
        get: function() {
          return this._caches.size;
        },
        enumerable: false,
        configurable: true
      });
      return ResourceCache;
    }();
    exports.ResourceCache = ResourceCache;
    cc._RF.pop();
  }, {} ],
  ResourceType: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "76ff7VNwrpA2YBkbXkmNLH2", "ResourceType");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.ResourceType = void 0;
    var ResourceType;
    (function(ResourceType) {
      ResourceType[ResourceType["Local"] = 0] = "Local";
      ResourceType[ResourceType["Remote"] = 1] = "Remote";
    })(ResourceType = exports.ResourceType || (exports.ResourceType = {}));
    cc._RF.pop();
  }, {} ],
  ServerConnector: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "f0074OZJWhLFprvOilPpr5s", "ServerConnector");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.ServerConnector = void 0;
    var SocketClient_1 = require("./SocketClient");
    var ServerConnector = function() {
      function ServerConnector() {
        this._wsClient = null;
        this._sendHartId = -1;
        this._curRecvHartTimeOutCount = 0;
        this._enabled = true;
        this._wsClient = new SocketClient_1.SocketClient();
        this._wsClient.onClose = this.onClose.bind(this);
        this._wsClient.onError = this.onError.bind(this);
        this._wsClient.onMessage = this.onMessage.bind(this);
        this._wsClient.onOpen = this.onOpen.bind(this);
      }
      ServerConnector.prototype.sendHeartbeat = function() {
        true;
        cc.error("\u8bf7\u91cd\u5199sendHeartbeat");
      };
      ServerConnector.prototype.getMaxHeartbeatTimeOut = function() {
        return 5;
      };
      ServerConnector.prototype.getHeartbeatInterval = function() {
        return 5e3;
      };
      ServerConnector.prototype.onHeartbeatTimeOut = function() {};
      ServerConnector.prototype.isHeartBeat = function(data) {
        return false;
      };
      ServerConnector.prototype.onOpen = function() {
        this._curRecvHartTimeOutCount = 0;
        this.stopSendHartSchedule();
        this.sendHeartbeat();
        this.startSendHartSchedule();
      };
      ServerConnector.prototype.onClose = function(ev) {
        this.stopSendHartSchedule();
      };
      ServerConnector.prototype.onError = function(ev) {
        this.stopSendHartSchedule();
      };
      ServerConnector.prototype.onMessage = function(data) {
        this.recvHeartbeat();
      };
      ServerConnector.prototype.recvHeartbeat = function() {
        this._curRecvHartTimeOutCount = 0;
      };
      Object.defineProperty(ServerConnector.prototype, "enabled", {
        get: function() {
          return this._enabled;
        },
        set: function(value) {
          this._enabled = value;
          false == value && this.close();
        },
        enumerable: false,
        configurable: true
      });
      ServerConnector.prototype.connect_server = function(ip, port, protocol) {
        void 0 === port && (port = null);
        void 0 === protocol && (protocol = "ws");
        if (!this.enabled) {
          true;
          cc.warn("\u8bf7\u6c42\u5148\u542f\u7528");
          return;
        }
        port ? "string" == typeof port && port.length > 0 ? this._wsClient && this._wsClient.initWebSocket(ip, port, protocol) : "number" == typeof port && port > 0 ? this._wsClient && this._wsClient.initWebSocket(ip, port.toString(), protocol) : this._wsClient && this._wsClient.initWebSocket(ip, null, protocol) : this._wsClient && this._wsClient.initWebSocket(ip, null, protocol);
      };
      ServerConnector.prototype.stopSendHartSchedule = function() {
        if (-1 != this._sendHartId) {
          clearInterval(this._sendHartId);
          this._sendHartId = -1;
        }
      };
      ServerConnector.prototype.startSendHartSchedule = function() {
        var self = this;
        this._sendHartId = setInterval(function() {
          self._curRecvHartTimeOutCount = self._curRecvHartTimeOutCount + 1;
          if (self._curRecvHartTimeOutCount > self.getMaxHeartbeatTimeOut()) {
            self.stopSendHartSchedule();
            self.onHeartbeatTimeOut();
            return;
          }
          self.sendHeartbeat();
        }, self.getHeartbeatInterval());
      };
      ServerConnector.prototype.sendBuffer = function(buffer) {
        this._wsClient && this._wsClient.send(buffer);
      };
      ServerConnector.prototype.close = function(isEnd) {
        void 0 === isEnd && (isEnd = false);
        this.stopSendHartSchedule();
        this._wsClient && this._wsClient.close(isEnd);
      };
      Object.defineProperty(ServerConnector.prototype, "isConnected", {
        get: function() {
          if (this._wsClient) return this._wsClient.isConnected;
          return false;
        },
        enumerable: false,
        configurable: true
      });
      return ServerConnector;
    }();
    exports.ServerConnector = ServerConnector;
    cc._RF.pop();
  }, {
    "./SocketClient": "SocketClient"
  } ],
  ServiceManager: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "b10b1KEbIxD2KA0GC+DMMc3", "ServiceManager");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.ServiceManager = void 0;
    var ServiceManager = function() {
      function ServiceManager() {
        this.services = [];
        this.services_names = {};
      }
      Object.defineProperty(ServiceManager, "Instance", {
        get: function() {
          return this._instance || (this._instance = new ServiceManager());
        },
        enumerable: false,
        configurable: true
      });
      ServiceManager.prototype.onLoad = function() {};
      ServiceManager.prototype.getServiceByNmame = function(name) {
        return this.services_names[name];
      };
      ServiceManager.prototype.addService = function(service, priority) {
        var className = cc.js.getClassName(service);
        this.services_names[className] = service;
        this.services.push(service);
        service.priority = priority;
      };
      ServiceManager.prototype.update = function() {
        this.services.forEach(function(value) {
          value && value.handMessage();
        });
      };
      ServiceManager.prototype.onDestroy = function() {
        this.services.forEach(function(value) {
          value && value.close(true);
        });
      };
      ServiceManager.prototype.close = function() {
        this.services.forEach(function(value) {
          value && value.close();
        });
      };
      ServiceManager.prototype.onEnterBackground = function() {
        this.services.forEach(function(value) {
          value && value.onEnterBackground();
        });
      };
      ServiceManager.prototype.onEnterForgeground = function(inBackgroundTime) {
        this.services.forEach(function(value) {
          value && value.onEnterForgeground(inBackgroundTime);
        });
      };
      ServiceManager._instance = null;
      return ServiceManager;
    }();
    exports.ServiceManager = ServiceManager;
    cc._RF.pop();
  }, {} ],
  Service: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "69960aChbJKwKN9Ey4bdl80", "Service");
    "use strict";
    var __extends = this && this.__extends || function() {
      var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function(d, b) {
          d.__proto__ = b;
        } || function(d, b) {
          for (var p in b) b.hasOwnProperty(p) && (d[p] = b[p]);
        };
        return extendStatics(d, b);
      };
      return function(d, b) {
        extendStatics(d, b);
        function __() {
          this.constructor = d;
        }
        d.prototype = null === b ? Object.create(b) : (__.prototype = b.prototype, new __());
      };
    }();
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.Service = void 0;
    var ENetEvent_1 = require("../../../Defineds/Events/ENetEvent");
    var EventManager_1 = require("../../Event/EventManager");
    var Process_1 = require("./Process");
    var ServerConnector_1 = require("./ServerConnector");
    var Service = function(_super) {
      __extends(Service, _super);
      function Service() {
        var _this = null !== _super && _super.apply(this, arguments) || this;
        _this._Process = new Process_1.Process();
        _this._Heartbeat = null;
        _this.serviceName = "CommonService";
        _this.priority = 0;
        return _this;
      }
      Object.defineProperty(Service.prototype, "Process", {
        set: function(val) {
          if (null == val) return;
          this._Process = new val();
        },
        enumerable: false,
        configurable: true
      });
      Object.defineProperty(Service.prototype, "Codec", {
        set: function(value) {
          this._Process.Codec = value;
        },
        enumerable: false,
        configurable: true
      });
      Object.defineProperty(Service.prototype, "heartbeat", {
        get: function() {
          return this._Heartbeat;
        },
        set: function(value) {
          this._Heartbeat = value;
        },
        enumerable: false,
        configurable: true
      });
      Service.prototype.onOpen = function() {
        _super.prototype.onOpen.call(this);
        EventManager_1.EventManager.dispatchEventWith(ENetEvent_1.ENetEvent.ON_OPEN, {
          service: this,
          event: null
        });
      };
      Service.prototype.onClose = function(ev) {
        _super.prototype.onClose.call(this, ev);
        EventManager_1.EventManager.dispatchEventWith(ENetEvent_1.ENetEvent.ON_CLOSE, {
          service: this,
          event: ev
        });
      };
      Service.prototype.onError = function(ev) {
        _super.prototype.onError.call(this, ev);
        EventManager_1.EventManager.dispatchEventWith(ENetEvent_1.ENetEvent.ON_ERROR, {
          service: this,
          event: ev
        });
      };
      Service.prototype.onMessage = function(data) {
        var header = new this._Process.Codec();
        if (!header.unPack(data)) {
          cc.error("decode header error");
          return;
        }
        _super.prototype.onMessage.call(this, data);
        if (this.isHeartBeat(header)) return;
        this._Process.onMessage(header);
      };
      Service.prototype.addListener = function(eventName, handleType, handleFunc, isQueue, target) {
        this._Process.addListener(eventName, handleType, handleFunc, isQueue, target);
      };
      Service.prototype.removeListeners = function(target, eventName) {
        this._Process.removeListeners(target, eventName);
      };
      Service.prototype.addMessageQueue = function(key, data, encode) {
        this._Process.addMessageQueue(key, data, encode);
      };
      Service.prototype.pauseMessageQueue = function() {
        this._Process.isPause = true;
      };
      Service.prototype.resumeMessageQueue = function() {
        this._Process.isPause = false;
      };
      Service.prototype.handMessage = function() {
        this._Process.handMessage();
      };
      Service.prototype.reset = function() {
        this._Process.reset();
      };
      Service.prototype.close = function(isEnd) {
        void 0 === isEnd && (isEnd = false);
        this._Process.close();
        _super.prototype.close.call(this, isEnd);
      };
      Service.prototype.send = function(msg) {
        if (this._Process.Codec) if (msg.encode()) {
          var header = new this._Process.Codec();
          header.pack(msg);
          if (this.isHeartBeat(msg)) {
            true;
            cc.log("send request cmd : " + msg.getCmdID() + " ");
          } else cc.log("send request main cmd : " + msg.getCmdID() + " ");
          this.sendBuffer(header.getData());
        } else cc.error("encode error"); else cc.error("\u8bf7\u6c42\u6307\u5b9a\u6570\u636e\u5305\u5934\u5904\u7406\u7c7b\u578b");
      };
      return Service;
    }(ServerConnector_1.ServerConnector);
    exports.Service = Service;
    cc._RF.pop();
  }, {
    "../../../Defineds/Events/ENetEvent": "ENetEvent",
    "../../Event/EventManager": "EventManager",
    "./Process": "Process",
    "./ServerConnector": "ServerConnector"
  } ],
  SocketClient: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "b07692w8S1IIoKPH8qMjqBa", "SocketClient");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.SocketClient = void 0;
    var SocketClient = function() {
      function SocketClient() {
        this._logtag = "SocketClient";
        this.wssCacertUrl = null;
        this._ip = "";
        this._port = null;
        this._protocol = "wss";
        this._dataArr = [];
        this._isWaitingConnect = false;
        this._conTimeOut = 10;
        this._sendTimeOut = 10;
        this._ws = null;
        this._onOpen = null;
        this._onClose = null;
        this._onMessage = null;
        this._onError = null;
        this._closeEvent = null;
      }
      Object.defineProperty(SocketClient.prototype, "connectTimeOut", {
        get: function() {
          return this._conTimeOut;
        },
        set: function(value) {
          this._conTimeOut = value;
        },
        enumerable: false,
        configurable: true
      });
      Object.defineProperty(SocketClient.prototype, "sendTimeOut", {
        get: function() {
          return this._sendTimeOut;
        },
        set: function(value) {
          this._sendTimeOut = value;
        },
        enumerable: false,
        configurable: true
      });
      Object.defineProperty(SocketClient.prototype, "onOpen", {
        get: function() {
          return this._onOpen;
        },
        set: function(value) {
          this._onOpen = value;
        },
        enumerable: false,
        configurable: true
      });
      Object.defineProperty(SocketClient.prototype, "onClose", {
        get: function() {
          return this._onClose;
        },
        set: function(value) {
          this._onClose = value;
        },
        enumerable: false,
        configurable: true
      });
      Object.defineProperty(SocketClient.prototype, "onMessage", {
        get: function() {
          return this._onMessage;
        },
        set: function(value) {
          this._onMessage = value;
        },
        enumerable: false,
        configurable: true
      });
      Object.defineProperty(SocketClient.prototype, "onError", {
        get: function() {
          return this._onError;
        },
        set: function(value) {
          this._onError = value;
        },
        enumerable: false,
        configurable: true
      });
      SocketClient.prototype.init = function(ip, port, protocol) {
        this._ip = ip;
        this._port = port;
        this._protocol = protocol;
        this._dataArr = [];
        this._conTimeOut = 10;
        this._sendTimeOut = 10;
        this._closeEvent = null;
      };
      SocketClient.prototype.connectWebSocket = function(ip, port, protocol) {
        this.init(ip, port, protocol);
        if (!this._ip) return;
        var fullUrl = protocol + "://" + this._ip;
        this._port && (fullUrl = fullUrl + ":" + this._port);
        true;
        cc.log("[" + this._logtag + "]", "initWebSocket : " + fullUrl);
        if (true, "wss" == protocol) {
          this.wssCacertUrl || cc.error("\u8bf7\u5148\u8bbe\u7f6ewss\u7684\u8bc1\u4e66url,MainController\u811a\u672c\u4e2d\u76f4\u63a5\u6302\u8f7d\u8bc1\u4e66");
          this._ws = new WebSocket(fullUrl, [], this.wssCacertUrl);
        } else this._ws = new WebSocket(fullUrl);
        this._ws.binaryType = "arraybuffer";
        this._ws.onopen = this.__onConected.bind(this);
        this._ws.onmessage = this.__onMessage.bind(this);
        this._ws.onclose = this.__onClose.bind(this);
        this._ws.onerror = this.__onError.bind(this);
        this._ws.readyState;
      };
      SocketClient.prototype.initWebSocket = function(ip, port, protocol) {
        if (void 0 == ip || null == ip || ip.length < 0) {
          true;
          cc.error("[" + this._logtag + "]", "init websocket error ip : " + ip + " port : " + port);
          return;
        }
        if (this._ws) if (this._ws.readyState == WebSocket.CONNECTING) {
          if (this._ip == ip && this._port == port) return;
          true;
          cc.error("[" + this._logtag + "]", "\u5f53\u524d\u6709\u6b63\u5728\u8fde\u63a5\u7684socket??");
        } else if (this._ws.readyState == WebSocket.OPEN) if (this._ip == ip && this._port == port) {
          true;
          cc.warn("[" + this._logtag + "]", "\u5f53\u524d\u8fde\u63a5\u5df2\u7ecf\u662f\u6253\u5f00\u7684\uff0c\u4e0d\u91cd\u590d\u8fde\u63a5");
        } else {
          true;
          cc.error("[" + this._logtag + "]", "\u5f53\u524d\u5df2\u7ecf\u5b58\u5728\u8fde\u63a5\uff0c\u8bf7\u5148\u5173\u95ed" + this._ip + ":" + this._port + " \u518d\u8fde\u63a5 " + ip + " : " + port);
        } else if (this._ws.readyState == WebSocket.CLOSING) {
          this._isWaitingConnect = true;
          this._ip = ip;
          this._port = port;
          true;
          cc.warn("[" + this._logtag + "]", "\u5f53\u524d\u7f51\u7edc\u5173\u95ed\u8fde\u63a5\u4e2d\uff0c\u5173\u95ed\u5b8c\u6210\u540e\u91cd\u65b0\u8fde\u63a5");
        } else {
          this._ws = null;
          this.connectWebSocket(ip, port, protocol);
        } else this.connectWebSocket(ip, port, protocol);
      };
      SocketClient.prototype.__onConected = function(event) {
        if (this._ws) {
          true;
          cc.log("[" + this._logtag + "]", "onConected state : " + this._ws.readyState);
        }
        if (this._dataArr.length > 0) {
          for (var i = 0; i < this._dataArr.length; i++) this.send(this._dataArr[i]);
          this._dataArr = [];
        }
        this.onOpen && this.onOpen();
      };
      SocketClient.prototype.__onMessage = function(arraybuffer) {
        var dataArr = new Uint8Array(arraybuffer.data);
        this.onMessage && this.onMessage(dataArr);
      };
      SocketClient.prototype.__onClose = function(event) {
        this._ws = null;
        if (this._closeEvent) {
          event = this._closeEvent;
          this._closeEvent = null;
        }
        if (event) {
          true;
          cc.log("[" + this._logtag + "]", "onClose type : " + event.type);
        } else {
          true;
          cc.log("[" + this._logtag + "]", "onClose");
        }
        if (this._isWaitingConnect) {
          true;
          cc.log("[" + this._logtag + "]", "\u6536\u5230\u8fde\u63a5\u5173\u95ed\uff0c\u6709\u7b49\u5f85\u8fde\u63a5\u7684\u7f51\u7edc\uff0c\u91cd\u8fde\u8fde\u63a5\u7f51\u7edc");
          this._closeEvent = null;
          this.connectWebSocket(this._ip, this._port, this._protocol);
          this._isWaitingConnect = false;
        } else this.onClose && this.onClose(event);
      };
      SocketClient.prototype.__onError = function(event) {
        if (event) {
          true;
          cc.error("[" + this._logtag + "]", "onError", event);
        } else {
          true;
          cc.error("[" + this._logtag + "]", "onError");
        }
        this.onError && this.onError(event);
      };
      Object.defineProperty(SocketClient.prototype, "isConnected", {
        get: function() {
          if (this._ws && this._ws.readyState === WebSocket.OPEN) return true;
          return false;
        },
        enumerable: false,
        configurable: true
      });
      SocketClient.prototype.send = function(data) {
        if (!this._ws || !data) return;
        if (this._ws.readyState === WebSocket.OPEN) this._ws.send(data); else if (this._ws.readyState == WebSocket.CONNECTING) this._dataArr.push(data); else {
          var content = this._ws.readyState == WebSocket.CLOSING ? "\u7f51\u7edc\u6b63\u5728\u5173\u95ed" : "\u7f51\u7edc\u5df2\u7ecf\u5173\u95ed";
          true;
          cc.warn("[" + this._logtag + "]", "\u53d1\u9001\u6d88\u606f\u5931\u8d25: " + content);
        }
      };
      SocketClient.prototype.close = function(isEnd) {
        if (this._ws) {
          this._closeEvent = {
            type: "CustomClose",
            isEnd: isEnd
          };
          this._ws.close();
        }
        this._dataArr = [];
        true;
        cc.log("[" + this._logtag + "]", "close websocket");
      };
      return SocketClient;
    }();
    exports.SocketClient = SocketClient;
    cc._RF.pop();
  }, {} ],
  Stack: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "89788h3Q7NM45yLe50KbSr8", "Stack");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var Stack = function() {
      function Stack() {
        this._array = null;
        this._array = new Array();
      }
      Stack.prototype.push = function(element) {
        var _a;
        if (null == element) return false;
        null === (_a = this._array) || void 0 === _a ? void 0 : _a.push(element);
        return true;
      };
      Stack.prototype.pop = function() {
        return this._array.pop();
      };
      Stack.prototype.first = function() {
        return this.isEmpty() ? null : this._array[0];
      };
      Stack.prototype.last = function() {
        return this.isEmpty() ? null : this._array[this.size() - 1];
      };
      Stack.prototype.get = function(index) {
        return this.isEmpty() ? null : this._array[index];
      };
      Stack.prototype.del = function(index) {
        !this.isEmpty() && index < this._array.length && this._array.splice(index, 1);
      };
      Stack.prototype.indexOf = function(element) {
        return this.isEmpty() ? -1 : this._array.indexOf(element);
      };
      Stack.prototype.size = function() {
        return this._array.length;
      };
      Stack.prototype.isEmpty = function() {
        return 0 === this.size();
      };
      Stack.prototype.clear = function() {
        this._array.length = 0;
      };
      return Stack;
    }();
    exports.default = Stack;
    cc._RF.pop();
  }, {} ],
  UIManager: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "e88fb1BNC5DuZZMJHjGPYlt", "UIManager");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.UIManager = void 0;
    var AssetsManager_1 = require("../Assets/AssetsManager");
    var EUIManager_1 = require("./../../Defineds/Events/EUIManager");
    var EventManager_1 = require("./../Event/EventManager");
    var ModuleComponent_1 = require("../../Component/ModuleComponent");
    var Layer_1 = require("../../Defineds/Enums/Layer");
    var ModuleStatusEnum_1 = require("../../Defineds/Enums/ModuleStatusEnum");
    var IResource_1 = require("../../Defineds/Interfaces/IResource");
    var LayerManager_1 = require("../Layer/LayerManager");
    var Const_1 = require("./Const");
    var ModuleData_1 = require("./ModuleData");
    var UIManager = function() {
      function UIManager() {
        this._logtag = "UIManager";
        this._moduleDatas = new Map();
      }
      Object.defineProperty(UIManager, "Instance", {
        get: function() {
          return this._instance || (this._instance = new UIManager());
        },
        enumerable: false,
        configurable: true
      });
      UIManager.prototype.preload = function(com, bundle) {
        return this._open(com, {
          ModuelConfig: {
            component: com,
            bundle: bundle
          }
        });
      };
      UIManager.prototype.openView = function(opt) {
        null != opt.ModuelConfig.bundle && "" != opt.ModuelConfig.bundle || (opt.ModuelConfig.bundle = "resources");
        null == opt.ModuelConfig.layer && (opt.ModuelConfig.layer = Layer_1.Layer.GameLayer.Content);
        null == opt.ModuelConfig.zIndex && (opt.ModuelConfig.layer = 0);
        this._open(opt.ModuelConfig.component, opt, false);
      };
      UIManager.prototype._open = function(module, opt, isPreload) {
        var _this = this;
        void 0 === isPreload && (isPreload = false);
        return new Promise(function(reslove) {
          if (!module) {
            true;
            cc.log("[" + _this._logtag + "]", "open ui class error");
            return reslove(null);
          }
          var className = cc.js.getClassName(module);
          var moduleData = _this.getViewData(module);
          if (moduleData) {
            moduleData.isPreload = isPreload;
            _this._openByViewData(moduleData, opt, isPreload, reslove);
          } else {
            moduleData = _this._getNewModuleData(module, opt, className, isPreload);
            var progressCallback = null;
            isPreload || (progressCallback = function(completedCount, totalCount, item) {
              var progress = Math.ceil(completedCount / totalCount * 100);
              EventManager_1.EventManager.dispatchEventWith(EUIManager_1.EUIManager.SHOW_LOADING, {
                name: opt.ModuelConfig.name,
                progress: progress,
                className: className
              });
            });
            _this.loadPrefab(opt.ModuelConfig.bundle, moduleData.ViewData.prefabUrl, progressCallback).then(function(prefab) {
              moduleData.info = new IResource_1.IResource.ResourceInfo();
              moduleData.info.url = moduleData.ViewData.prefabUrl;
              moduleData.info.type = cc.Prefab;
              moduleData.info.data = prefab;
              moduleData.info.bundle = opt.ModuelConfig.bundle;
              AssetsManager_1.AssetsManager.Instance.retainAsset(moduleData.info);
              _this._createNode(className, reslove);
              EventManager_1.EventManager.dispatchEventWith(EUIManager_1.EUIManager.HIDE_LOADING);
            }).catch(function(reason) {
              moduleData.isLoaded = true;
              cc.error(reason);
              _this.close(module);
              moduleData.doCallback(null, className, "\u6253\u5f00\u754c\u9762\u5f02\u5e38");
              reslove(null);
              var uiName = "";
              true;
              uiName = className;
              opt.ModuelConfig.name && (uiName = opt.ModuelConfig.name);
              EventManager_1.EventManager.dispatchEventWith(EUIManager_1.EUIManager.HIDE_LOADING);
            });
          }
        });
      };
      UIManager.prototype._createNode = function(className, reslove) {
        var moduleData = this._moduleDatas.get(className);
        if (!moduleData) return;
        moduleData.isLoaded = true;
        if (moduleData.status == ModuleStatusEnum_1.ModuleStatusEnum.WAITTING_CLOSE) {
          reslove(null);
          true;
          cc.warn("[" + this._logtag + "]", className + "\u6b63\u7b49\u5f85\u5173\u95ed");
          moduleData.doCallback(null, className, "\u83b7\u53d6\u754c\u5185\u5df2\u7ecf\u5173\u95ed");
          return;
        }
        var uiNode = cc.instantiate(moduleData.info.data);
        moduleData.node = uiNode;
        var view = this._addComponent(uiNode, moduleData);
        if (!view) return reslove(null);
        if (moduleData.status == ModuleStatusEnum_1.ModuleStatusEnum.WATITING_HIDE) {
          view.hide({
            onHided: function() {
              moduleData.ViewData.hided && moduleData.ViewData.hided();
            }
          });
          true;
          cc.warn("[" + this._logtag + "]", "\u52a0\u8f7d\u8fc7\u7a0b\u9690\u85cf\u4e86\u754c\u9762" + className);
          reslove(view);
          moduleData.doCallback(view, className, "\u52a0\u8f7d\u5b8c\u6210\uff0c\u4f46\u52a0\u8f7d\u8fc7\u7a0b\u4e2d\u88ab\u9690\u85cf");
        } else {
          true;
          cc.log("[" + this._logtag + "]", "\u6b63\u5728\u6253\u5f00module: " + className);
          moduleData.isPreload || view.show({
            data: moduleData.ViewData.data,
            onShowed: function() {
              moduleData.ViewData.showed && moduleData.ViewData.showed();
            }
          });
          reslove(view);
          moduleData.doCallback(view, className, "\u52a0\u8f7d\u5b8c\u6210\uff0c\u56de\u8c03\u4e4b\u524d\u52a0\u8f7d\u4e2d\u7684\u754c\u9762");
        }
      };
      UIManager.prototype._addComponent = function(uiNode, moduleData) {
        if (!uiNode) return null;
        var component = uiNode.getComponent(ModuleComponent_1.ModuleComponent);
        if (!component) {
          component = uiNode.addComponent(moduleData.ViewData.component);
          if (!component) {
            true;
            cc.error("[" + this._logtag + "]", "\u6302\u8f7d\u811a\u672c\u5931\u8d25 : " + moduleData.loadData.name);
            return null;
          }
          true;
          cc.log("[" + this._logtag + "]", "\u6302\u8f7d\u811a\u672c : " + moduleData.loadData.name);
        }
        component.bundle = moduleData.ViewData.bundle;
        moduleData.component = component;
        var widget = component.getComponent(cc.Widget);
        if (widget) {
          true;
          cc.warn("[" + this._logtag + "]", "\u4f60\u5df2\u7ecf\u6dfb\u52a0\u4e86cc.Widget\u7ec4\u4ef6\uff0c\u5c06\u4f1a\u66f4\u6539\u6210\u5c45\u4e2d\u6a21\u5757");
          widget.isAlignHorizontalCenter = true;
          widget.horizontalCenter = 0;
          widget.isAlignVerticalCenter = true;
          widget.verticalCenter = 0;
        } else {
          widget = component.addComponent(cc.Widget);
          widget.isAlignHorizontalCenter = true;
          widget.horizontalCenter = 0;
          widget.isAlignVerticalCenter = true;
          widget.verticalCenter = 0;
        }
        moduleData.isPreload || this.addChild(uiNode, moduleData.ViewData.layer, moduleData.ViewData.zIndex, component);
        return component;
      };
      UIManager.prototype.loadPrefab = function(bundle, url, progressCallback) {
        return new Promise(function(resolove, reject) {
          void 0 != bundle && "" != bundle && null != bundle || (bundle = Const_1.BUNDLE_RESOURCES);
          AssetsManager_1.AssetsManager.Instance.load(bundle, url, cc.Prefab, progressCallback, function(data) {
            data && data.data && data.data instanceof cc.Prefab ? resolove(data.data) : reject("\u52a0\u8f7dprefab : " + url + " \u5931\u8d25");
          });
        });
      };
      UIManager.prototype._getNewModuleData = function(module, opt, className, isPreload) {
        var moduleData = new ModuleData_1.ModuleData();
        var prefabUrl = module.getPrefabUrl();
        moduleData.isPreload = isPreload;
        moduleData.loadData.name = className;
        moduleData.ViewData.prefabUrl = prefabUrl;
        moduleData.ViewData.bundle = opt.ModuelConfig.bundle;
        moduleData.ViewData.component = module;
        moduleData.ViewData.showed = opt.onShowed;
        moduleData.ViewData.layer = opt.ModuelConfig.layer;
        moduleData.ViewData.zIndex = opt.ModuelConfig.zIndex;
        moduleData.ViewData.data = opt.data;
        this._moduleDatas.set(className, moduleData);
        return moduleData;
      };
      UIManager.prototype._openByViewData = function(viewData, opt, isPreload, reslove) {
        var _this = this;
        if (viewData.isLoaded) {
          viewData.status = ModuleStatusEnum_1.ModuleStatusEnum.WAITTING_NONE;
          if (!isPreload && viewData.component && cc.isValid(viewData.node)) {
            viewData.node.zIndex = opt.ModuelConfig.zIndex;
            viewData.node.parent || this.addChild(viewData.node, opt.ModuelConfig.layer, opt.ModuelConfig.zIndex, viewData.component);
            viewData.component.show({
              data: opt.data,
              onShowed: function() {
                true;
                cc.log("[" + _this._logtag + "]", "\u6253\u5f00 module \u5b8c\u6210");
                opt.onShowed && opt.onShowed();
              }
            });
          }
          return reslove(viewData.component);
        }
        viewData.status = ModuleStatusEnum_1.ModuleStatusEnum.WAITTING_NONE;
        true;
        cc.warn("[" + this._logtag + "]", viewData.loadData.name + " \u6b63\u5728\u52a0\u8f7d\u4e2d...");
        viewData.finishCb.push(reslove);
        return;
      };
      UIManager.prototype.addChild = function(node, layer, zIndex, adpater) {
        void 0 === layer && (layer = 0);
        void 0 === zIndex && (zIndex = 0);
        void 0 === adpater && (adpater = null);
        if (!node) return;
        LayerManager_1.LayerManager.Instance.getLayer(layer).addChild(node, zIndex);
      };
      UIManager.prototype.checkView = function(url, className) {
        var _this = this;
        (true, className) && this.getView(className).then(function(view) {
          if (!view) {
            var viewData = _this.getViewData(className);
            viewData && viewData.isPreload || cc.error("[" + _this._logtag + "]", "\u8d44\u6e90 : " + url + " \u7684\u6301\u6709\u8005\u5fc5\u987b\u7531UIManager.open\u65b9\u5f0f\u6253\u5f00");
          }
        });
      };
      UIManager.prototype.getView = function(data) {
        var _this = this;
        return new Promise(function(reslove, reject) {
          if (void 0 == data || null == data) return reslove(null);
          var viewData = _this.getViewData(data);
          viewData ? viewData.isPreload ? reslove(null) : viewData.isLoaded ? reslove(viewData.component) : viewData.getViewCb.push(reslove) : reslove(null);
        });
      };
      UIManager.prototype.getViewData = function(data) {
        var className = this.getClassName(data);
        if (!className) return null;
        var module = this._moduleDatas.has(className) ? this._moduleDatas.get(className) : null;
        return module;
      };
      UIManager.prototype.getClassName = function(data) {
        if (!data) return null;
        var className = null;
        className = "string" == typeof data ? data : cc.js.getClassName(data);
        return className;
      };
      UIManager.prototype.close = function(data) {
        var module = this.getViewData(data);
        if (module) {
          module.status = ModuleStatusEnum_1.ModuleStatusEnum.WAITTING_CLOSE;
          if (module.component && cc.isValid(module.node)) {
            module.component.close();
            module.node.removeFromParent(true);
            module.node.destroy();
          }
          module.loadData.clear();
          var className = this.getClassName(data);
          AssetsManager_1.AssetsManager.Instance.releaseAsset(module.info);
          this._moduleDatas.delete(className);
          cc.log("[" + this._logtag + "]   close module : " + className);
        }
      };
      UIManager.prototype.hide = function(opt) {
        var _this = this;
        var module = this.getViewData(opt.ModuelConfig.component);
        if (module) if (module.isLoaded) {
          module.component && cc.isValid(module.component.node) && module.component.show({
            data: opt.data,
            onShowed: function() {
              true;
              cc.log("[" + _this._logtag + "]", "\u88ab\u9690\u85cf\u7684module");
              opt.onHided && opt.onHided();
            }
          });
          true;
          cc.log("[" + this._logtag + "]", "hide view : " + module.loadData.name);
        } else {
          module.ViewData.hided = opt.onHided;
          module.ViewData.data = opt.data;
          module.status = ModuleStatusEnum_1.ModuleStatusEnum.WATITING_HIDE;
        }
      };
      UIManager._instance = null;
      return UIManager;
    }();
    exports.UIManager = UIManager;
    cc._RF.pop();
  }, {
    "../../Component/ModuleComponent": "ModuleComponent",
    "../../Defineds/Enums/Layer": "Layer",
    "../../Defineds/Enums/ModuleStatusEnum": "ModuleStatusEnum",
    "../../Defineds/Interfaces/IResource": "IResource",
    "../Assets/AssetsManager": "AssetsManager",
    "../Layer/LayerManager": "LayerManager",
    "./../../Defineds/Events/EUIManager": "EUIManager",
    "./../Event/EventManager": "EventManager",
    "./Const": "Const",
    "./ModuleData": "ModuleData"
  } ],
  Updater: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "57113x3t8JAS6XOPZm8DAue", "Updater");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.Updater = void 0;
    var HotUpdateEnums_1 = require("../../Defineds/Enums/HotUpdateEnums");
    var EUpdater_1 = require("../../Defineds/Events/EUpdater");
    var EventManager_1 = require("../Event/EventManager");
    var Updater = function() {
      function Updater(option, _updateCallback, onCompolete) {
        this.option = option;
        this._updateCallback = _updateCallback;
        this.onCompolete = onCompolete;
        this.updating = false;
        this.curAssetsManager = null;
        this.storagePath = "";
        null != this.option && "" == this.option.name && (this.option.name = "MainPackage");
        this.initAssetsManager();
      }
      Updater.prototype.initAssetsManager = function() {
        if (this._isNeedUpdate(this._updateCallback)) {
          this.curAssetsManager = this._getAssetsManager();
          this.localFileExist();
        }
      };
      Updater.prototype.localFileExist = function() {
        var manifestUrl = this.option.isMain ? this._getMainfestUrl : this._getSubMainfestUrl;
        if (jsb.fileUtils.isFileExist(manifestUrl)) {
          var content = jsb.fileUtils.getStringFromFile(manifestUrl);
          var jsbGameManifest = new jsb.Manifest(content, this.storagePath, this.option.updateAddress);
          console.log("[" + this.option.name + "_Updater]", "--\u5b58\u5728\u672c\u5730\u7248\u672c\u63a7\u5236\u6587\u4ef6checkUpdate--");
          console.log("[" + this.option.name + "_Updater]", "mainifestUrl : " + manifestUrl);
          this.curAssetsManager.manager.loadLocalManifest(jsbGameManifest, "");
        } else {
          if (this.updating) {
            console.log("[" + this.option.name + "_Updater]", "Checking or updating...");
            this._updateCallback(HotUpdateEnums_1.HotUpdateEnums.Code.CHECKING, HotUpdateEnums_1.HotUpdateEnums.State.PREDOWNLOAD_VERSION);
            return;
          }
          var packageUrl = this.option.updateAddress;
          var gameManifest = {
            version: "0",
            packageUrl: packageUrl,
            remoteManifestUrl: packageUrl + "/" + manifestUrl,
            remoteVersionUrl: packageUrl + "/" + this.option.manifestRoot + "/" + this.option.name + "_version.manifest",
            assets: {},
            searchPaths: []
          };
          var gameManifestContent = JSON.stringify(gameManifest);
          var jsbGameManifest = new jsb.Manifest(gameManifestContent, this.storagePath, this.option.name);
          console.log("[" + this.option.name + "_Updater]", "--checkUpdate--");
          console.log("[" + this.option.name + "_Updater]", "mainifest content : " + gameManifestContent);
          this.curAssetsManager.manager.loadLocalManifest(jsbGameManifest, "");
          this.checkUpdate();
        }
        this.checkUpdate();
      };
      Object.defineProperty(Updater.prototype, "_getMainfestUrl", {
        get: function() {
          return this.option.manifestRoot + "/project.manifest";
        },
        enumerable: false,
        configurable: true
      });
      Object.defineProperty(Updater.prototype, "_getSubMainfestUrl", {
        get: function() {
          return this.option.manifestRoot + "/" + this.option.name + "_project.manifest";
        },
        enumerable: false,
        configurable: true
      });
      Updater.prototype._getAssetsManager = function() {
        var _this = this;
        true;
        this.storagePath = jsb.fileUtils.getWritablePath();
        console.log("[" + this.option.name + "_Updater]", "Storage path for remote asset:" + this.storagePath);
        var am = new AssetsManager(this.option.name);
        am.manager = new jsb.AssetsManager(this.option.isMain ? "type.hall" : "type." + this.option.name + "_", this.storagePath, this.versionCompareHanle.bind(this));
        am.manager.setMaxConcurrentTask(8);
        am.manager.setHotUpdateUrl(this.option.updateAddress);
        am.manager.setVerifyCallback(function(path, asset) {
          var compressed = asset.compressed;
          var expectedMD5 = asset.md5;
          var relativePath = asset.path;
          var size = asset.size;
          if (compressed) {
            console.log("[" + _this.option.name + "_Updater]", "Verification passed : " + relativePath);
            return true;
          }
          console.log("[" + _this.option.name + "_Updater]", "Verification passed : " + relativePath + " ( " + expectedMD5 + " )");
          return true;
        });
        return am;
      };
      Object.defineProperty(Updater.prototype, "isBrowser", {
        get: function() {
          return cc.sys.platform == cc.sys.WECHAT_GAME || cc.sys.isBrowser;
        },
        enumerable: false,
        configurable: true
      });
      Updater.prototype.checkUpdate = function() {
        if (this._isNeedUpdate(this._updateCallback)) {
          console.log("[" + this.option.name + "_Updater]", "checkUpdate");
          if (this.updating) {
            console.log("[" + this.option.name + "_Updater]", "Checking or updating...");
            this._updateCallback(HotUpdateEnums_1.HotUpdateEnums.Code.CHECKING, HotUpdateEnums_1.HotUpdateEnums.State.PREDOWNLOAD_VERSION);
            return;
          }
          if (!this.curAssetsManager.manager.getLocalManifest() || !this.curAssetsManager.manager.getLocalManifest().isLoaded()) {
            console.log("[" + this.option.name + "_Updater]", "Failed to load local manifest ....");
            this._updateCallback(HotUpdateEnums_1.HotUpdateEnums.Code.ERROR_DOWNLOAD_MANIFEST, HotUpdateEnums_1.HotUpdateEnums.State.FAIL_TO_UPDATE);
            return;
          }
          if (this.isTryDownloadFailedAssets()) {
            console.log("[" + this.option.name + "_Updater]", "\u4e4b\u524d\u4e0b\u8f7d\u8d44\u6e90\u672a\u5b8c\u5168\u4e0b\u8f7d\u5b8c\u6210\uff0c\u8bf7\u5c1d\u8bd5\u91cd\u65b0\u4e0b\u8f7d");
            this._updateCallback(HotUpdateEnums_1.HotUpdateEnums.Code.UPDATE_FAILED, HotUpdateEnums_1.HotUpdateEnums.State.TRY_DOWNLOAD_FAILED_ASSETS);
          } else {
            this.updating = true;
            this.curAssetsManager.manager.setEventCallback(this.checkCb.bind(this));
            this.curAssetsManager.manager.checkUpdate();
          }
        }
      };
      Updater.prototype.isTryDownloadFailedAssets = function() {
        if (this.curAssetsManager && (this.curAssetsManager.manager.getState() == HotUpdateEnums_1.HotUpdateEnums.State.FAIL_TO_UPDATE || this.curAssetsManager.code == HotUpdateEnums_1.HotUpdateEnums.Code.ERROR_NO_LOCAL_MANIFEST || this.curAssetsManager.code == HotUpdateEnums_1.HotUpdateEnums.Code.ERROR_DOWNLOAD_MANIFEST || this.curAssetsManager.code == HotUpdateEnums_1.HotUpdateEnums.Code.ERROR_PARSE_MANIFEST)) return true;
        return false;
      };
      Updater.prototype._isNeedUpdate = function(callback) {
        if (this.isBrowser) {
          this.updating = false;
          callback(HotUpdateEnums_1.HotUpdateEnums.Code.ALREADY_UP_TO_DATE, HotUpdateEnums_1.HotUpdateEnums.State.UP_TO_DATE);
          return false;
        }
        if (this.option.isSkip) {
          console.log("[" + this.option.name + "_Updater]", "\u8df3\u8fc7\u70ed\u66f4\u65b0\uff0c\u76f4\u63a5\u4f7f\u7528\u672c\u5730\u8d44\u6e90\u4ee3\u7801");
          this.updating = false;
          callback(HotUpdateEnums_1.HotUpdateEnums.Code.ALREADY_UP_TO_DATE, HotUpdateEnums_1.HotUpdateEnums.State.UP_TO_DATE);
        }
        return !this.option.isSkip;
      };
      Updater.prototype.checkCb = function(event) {
        this.curAssetsManager.code = event.getEventCode();
        console.log("[" + this.option.name + "_Updater]", "checkCb event code : " + event.getEventCode() + " state : " + this.curAssetsManager.manager.getState());
        switch (event.getEventCode()) {
         case HotUpdateEnums_1.HotUpdateEnums.Code.ERROR_NO_LOCAL_MANIFEST:
          console.log("[" + this.option.name + "_Updater]", "No local manifest file found, hot update skipped.");
          break;

         case HotUpdateEnums_1.HotUpdateEnums.Code.ERROR_DOWNLOAD_MANIFEST:
         case HotUpdateEnums_1.HotUpdateEnums.Code.ERROR_PARSE_MANIFEST:
          console.log("[" + this.option.name + "_Updater]", "Fail to download manifest file, hot update skipped.");
          break;

         case HotUpdateEnums_1.HotUpdateEnums.Code.ALREADY_UP_TO_DATE:
          console.log("[" + this.option.name + "_Updater]", "Already up to date with the latest remote version.");
          break;

         case HotUpdateEnums_1.HotUpdateEnums.Code.NEW_VERSION_FOUND:
          console.log("[" + this.option.name + "_Updater]", "New version found, please try to update.");
          break;

         default:
          return;
        }
        this.updating = false;
        if (this._updateCallback && this.curAssetsManager.manager.getState() != HotUpdateEnums_1.HotUpdateEnums.State.DOWNLOADING_VERSION) {
          this._updateCallback(event.getEventCode(), this.curAssetsManager.manager.getState());
          this.curAssetsManager = null;
        }
      };
      Updater.prototype.downloadFailedAssets = function() {
        this.curAssetsManager && this.curAssetsManager.manager.downloadFailedAssets();
      };
      Updater.prototype.versionCompareHanle = function(versionA, versionB) {
        console.log("[" + this.option.name + "_Updater]", "JS Custom Version Compare : version A is " + versionA + " , version B is " + versionB);
        var vA = versionA.split(".");
        var vB = versionB.split(".");
        console.log("[" + this.option.name + "_Updater]", "version A " + vA + " , version B " + vB);
        for (var i = 0; i < vA.length && i < vB.length; ++i) {
          var a = parseInt(vA[i]);
          var b = parseInt(vB[i]);
          if (a === b) continue;
          return a - b;
        }
        if (vB.length > vA.length) return -1;
        return 0;
      };
      Updater.prototype.runHotUpdate = function() {
        if (this.curAssetsManager) {
          cc.error("[" + this.option.name + "_Updater]", "\u70ed\u66f4\u65b0\u5668\u672a\u521d\u59cb\u5316");
          return;
        }
        console.log("\u5373\u5c06\u70ed\u66f4\u65b0\u6a21\u5757\u4e3a:" + this.option.name + " , updating : " + this.updating);
        if (!this.updating) {
          console.log("[" + this.option.name + "_Updater]", "\u6267\u884c\u66f4\u65b0 " + this.curAssetsManager.name + " ");
          this.curAssetsManager.manager.setEventCallback(this.updateCb.bind(this));
          this.curAssetsManager.manager.update();
        }
      };
      Updater.prototype.updateCb = function(event) {
        var isUpdateFinished = false;
        var failed = false;
        console.log("[" + this.option.name + "_Updater]", "--update cb code : " + event.getEventCode() + " state : " + this.curAssetsManager.manager.getState());
        this.curAssetsManager.code = event.getEventCode();
        switch (event.getEventCode()) {
         case HotUpdateEnums_1.HotUpdateEnums.Code.ERROR_NO_LOCAL_MANIFEST:
          console.log("[" + this.option.name + "_Updater]", "No local manifest file found, hot update skipped.");
          failed = true;
          break;

         case HotUpdateEnums_1.HotUpdateEnums.Code.UPDATE_PROGRESSION:
          console.log("[" + this.option.name + "_Updater]", event.getDownloadedBytes() + " / " + event.getTotalBytes());
          console.log("[" + this.option.name + "_Updater]", event.getDownloadedFiles() + " / " + event.getTotalFiles());
          console.log("[" + this.option.name + "_Updater]", "percent : " + event.getPercent());
          console.log("[" + this.option.name + "_Updater]", "percent by file : " + event.getPercentByFile());
          var msg = event.getMessage();
          msg && console.log("[" + this.option.name + "_Updater]", "Updated file: " + msg);
          break;

         case HotUpdateEnums_1.HotUpdateEnums.Code.ERROR_DOWNLOAD_MANIFEST:
         case HotUpdateEnums_1.HotUpdateEnums.Code.ERROR_PARSE_MANIFEST:
          console.log("[" + this.option.name + "_Updater]", "Fail to download manifest file, hot update skipped.");
          failed = true;
          break;

         case HotUpdateEnums_1.HotUpdateEnums.Code.ALREADY_UP_TO_DATE:
          console.log("[" + this.option.name + "_Updater]", "Already up to date with the latest remote version.");
          failed = true;
          break;

         case HotUpdateEnums_1.HotUpdateEnums.Code.UPDATE_FINISHED:
          console.log("[" + this.option.name + "_Updater]", "Update finished. " + event.getMessage());
          isUpdateFinished = true;
          break;

         case HotUpdateEnums_1.HotUpdateEnums.Code.UPDATE_FAILED:
          console.log("[" + this.option.name + "_Updater]", "Update failed. " + event.getMessage());
          this.updating = false;
          break;

         case HotUpdateEnums_1.HotUpdateEnums.Code.ERROR_UPDATING:
          console.log("[" + this.option.name + "_Updater]", "Asset update error: " + event.getAssetId() + " , " + event.getMessage());
          break;

         case HotUpdateEnums_1.HotUpdateEnums.Code.ERROR_DECOMPRESS:
          console.log("[" + this.option.name + "_Updater]", "" + event.getMessage());
        }
        if (failed) {
          this.curAssetsManager.manager.setEventCallback(null);
          this.updating = false;
        }
        if (isUpdateFinished) {
          var searchPaths = jsb.fileUtils.getSearchPaths();
          var newPaths = this.curAssetsManager.manager.getLocalManifest().getSearchPaths();
          console.log(JSON.stringify(newPaths));
          Array.prototype.unshift.apply(searchPaths, newPaths);
          var obj = {};
          for (var i = 0; i < searchPaths.length; i++) obj[searchPaths[i]] = true;
          searchPaths = Object.keys(obj);
          cc.sys.localStorage.setItem("HotUpdateSearchPaths", JSON.stringify(searchPaths));
          jsb.fileUtils.setSearchPaths(searchPaths);
        }
        var state = this.curAssetsManager.manager.getState();
        if (this.option.isMain) {
          if (isUpdateFinished) {
            this.curAssetsManager.manager.setEventCallback(null);
            event.getDownloadedFiles() > 0 && cc.game.restart();
            this.onCompolete && this.onCompolete();
          }
        } else if (isUpdateFinished) {
          console.log("[" + this.option.name + "_Updater]", this.curAssetsManager.name + " \u4e0b\u8f7d\u8d44\u6e90\u6570 : " + event.getDownloadedFiles());
          this.onCompolete && this.onCompolete();
        }
        var info = {
          downloadedBytes: event.getDownloadedBytes(),
          totalBytes: event.getTotalBytes(),
          downloadedFiles: event.getDownloadedFiles(),
          totalFiles: event.getTotalFiles(),
          percent: event.getPercent(),
          percentByFile: event.getPercentByFile(),
          code: event.getEventCode(),
          state: state,
          needRestart: isUpdateFinished,
          name: this.option.name
        };
        EventManager_1.EventManager.dispatchEventWith(EUpdater_1.EUpdater.HOTUPDATE_DOWNLOAD, info);
        console.log("[" + this.option.name + "_Updater]", "update cb  failed : " + failed + "  , need restart : " + isUpdateFinished + " , updating : " + this.updating);
      };
      return Updater;
    }();
    exports.Updater = Updater;
    var AssetsManager = function() {
      function AssetsManager(name) {
        this.code = -1;
        this.name = "";
        this.manager = null;
        this.name = name;
      }
      return AssetsManager;
    }();
    cc._RF.pop();
  }, {
    "../../Defineds/Enums/HotUpdateEnums": "HotUpdateEnums",
    "../../Defineds/Events/EUpdater": "EUpdater",
    "../Event/EventManager": "EventManager"
  } ]
}, {}, [ "Application", "PopupControll", "PopupModule", "ProcessLoading", "Config", "GameModel", "EventComponent", "ModuleBinder", "ModuleComponent", "Macro", "Decorator", "HotUpdateEnums", "Layer", "ModuleStatusEnum", "ResourceCacheStatus", "ResourceType", "EBundle", "ENetEvent", "EUIManager", "EUpdater", "IDestroy", "IGameEventInterface", "IListenerData", "IMessage", "IModuleConfig", "IModuleDataLoadData", "IModuleOption", "IResource", "IUIClass", "IUpdater", "BitEncrypt", "Framework", "Dictionary", "InjectData", "InjectObjectUtility", "AssetsManager", "CacheManager", "RemoteCaches", "RemoteLoader", "ResourceCache", "BundleManager", "EntryManager", "GameEntry", "EventDispather", "EventManager", "EventOption", "HotUpdateManger", "Updater", "LayerManager", "LocalStorage", "ServiceManager", "ICommonService", "Process", "ServerConnector", "Service", "SocketClient", "Const", "ModuleData", "ModuleDynamicLoadData", "UIManager", "Queue", "Stack", "GameItemBinder", "GameList", "MainModuleConfig", "MainEvents", "Main", "MainGameEntry", "BootModule", "LobbyModule", "LoginModule" ]);