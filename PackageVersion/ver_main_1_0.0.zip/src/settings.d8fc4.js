window._CCSettings = {
    platform: "win32",
    groupList: [
        "default"
    ],
    collisionMatrix: [
        [
            true
        ]
    ],
    hasResourcesBundle: true,
    hasStartSceneBundle: false,
    remoteBundles: [],
    subpackages: [],
    launchScene: "db://assets/main.fire",
    orientation: "",
    server: "",
    debug: true,
    jsList: [],
    bundleVers: {
        internal: "5e2d8",
        gameOne: "39a42",
        gameTwo: "92ede",
        resources: "26176",
        main: "9cf46"
    }
};
